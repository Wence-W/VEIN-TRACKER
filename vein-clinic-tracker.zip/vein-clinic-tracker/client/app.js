import Chart from 'chart.js/auto';
import * as XLSX from 'xlsx';
import feather from 'feather-icons';
import { initializeApp } from 'firebase/app';
import {
  initializeAuth, browserLocalPersistence, sendSignInLinkToEmail, isSignInWithEmailLink,
  signInWithEmailLink, onAuthStateChanged, signOut as fbSignOut
} from 'firebase/auth';

/* ============================================================
   Constants (same tabs, fields and options as the prototype)
   ============================================================ */
const GROUPS = { intake: 'Intake', surgeon: 'Surgeon queues', postop: 'Post-op', closed: 'Closed' };
const TABS = [
  { key: 'Promo', group: 'intake', type: 'promo', nameRequired: false, icon: 'tag',
    blurb: 'Promo inquiries and ultrasound scheduling. BBA ID is optional.' },
  { key: 'Procter Pay Attention', group: 'intake', type: 'clinical', nameRequired: false, icon: 'flag',
    blurb: 'Cases flagged for Dr. Procter’s review. BBA ID is optional.' },
  { key: 'Dr. Procter', group: 'surgeon', type: 'clinical', nameRequired: true, icon: 'user', surgeonMatch: /procter/i,
    blurb: 'Pre-authorization queue for Dr. Procter. BBA ID is required.' },
  { key: 'Dr. Danthuluri', group: 'surgeon', type: 'clinical', nameRequired: true, icon: 'user', surgeonMatch: /danthuluri/i,
    blurb: 'Pre-authorization queue for Dr. Danthuluri. BBA ID is required.' },
  { key: 'PO Vein FU', group: 'postop', type: 'po', nameRequired: true, icon: 'calendar',
    blurb: 'Post-op follow-up at 30 days, 3, 6 and 12 months. BBA ID is required.' },
  { key: 'PA DENIED', group: 'closed', type: 'clinical', nameRequired: true, icon: 'x-octagon',
    blurb: 'Prior authorizations that were denied. BBA ID is required.' },
  { key: 'Not Interested Now or excluded', group: 'closed', type: 'clinical', nameRequired: true, icon: 'pause-circle',
    blurb: 'Patients who declined for now or were excluded. BBA ID is required.' }
];
const TAB = Object.fromEntries(TABS.map(t => [t.key, t]));
const ADMIN = [
  { key: 'surgeons', label: 'Surgeon roster', icon: 'briefcase', blurb: 'Surgeons available on clinical records.' },
  { key: 'users', label: 'Authorized users', icon: 'shield', blurb: 'Staff emails allowed to sign in.', adminOnly: true },
  { key: 'activity', label: 'Activity log', icon: 'list', blurb: 'Who changed what, and when.', adminOnly: true },
  { key: 'settings', label: 'Settings', icon: 'settings', blurb: 'Practice details, display and data.' }
];

const VEINS = [
  { k: 'gsv', label: 'GSV', full: 'Great saphenous' },
  { k: 'ssv', label: 'SSV', full: 'Small saphenous' },
  { k: 'pasv', label: 'PASV', full: 'Posterior accessory saphenous' },
  { k: 'aasv', label: 'AASV', full: 'Anterior accessory saphenous' },
  { k: 'btk', label: 'BTK', full: 'Below the knee' }
];
const SIDES = [{ k: 'r', label: 'Right' }, { k: 'l', label: 'Left' }];
const VEIN_KEYS = SIDES.flatMap(s => VEINS.map(v => `${s.k}_${v.k}`));
const PROCS = ['None', 'RFA', 'Varithena', 'Venaseal'];
const POST_STATUS = [
  { v: '', l: 'Not started' }, { v: 'Ordered', l: 'Ordered' }, { v: 'Scheduled', l: 'Scheduled' },
  { v: 'Completed', l: 'Completed' }, { v: 'Not needed', l: 'Not needed' }
];
const MILESTONES = [
  { k: 'po30Day', label: '30-day PO' },
  { k: 'po3Month', label: '3-month PO' },
  { k: 'po6Month', label: '6-month PO' },
  { k: 'po12Month', label: '12-month PO' }
];
const LOCATIONS = ['ATL', 'STB', 'Newnan'];
const IV_OPTIONS = ['', 'IV', 'Vanquish', 'Both', 'None'];
const PA_STATUS = [
  { v: '', l: 'Not submitted' }, { v: 'Submitted', l: 'Submitted' }, { v: 'Pending', l: 'Pending' },
  { v: 'Approved', l: 'Approved' }, { v: 'Denied', l: 'Denied' }
];
const INITIAL_US = [
  { v: '', l: 'Not received' }, { v: 'Requested', l: 'Requested' }, { v: 'Received', l: 'Received' },
  { v: 'Reviewed', l: 'Reviewed' }, { v: 'Not needed', l: 'Not needed' }
];
const SYNC_MS = 15000;

/* ============================================================
   Helpers
   ============================================================ */
const $ = s => document.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const localISO = (d = new Date()) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const addDays = (n, from = new Date()) => localISO(new Date(from.getTime() + n * 864e5));
const fmtDate = iso => {
  if (!iso) return '';
  const d = new Date(iso + 'T00:00:00');
  return isNaN(d) ? String(iso) : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
};
const daysFromToday = iso => Math.round((new Date(iso + 'T00:00:00') - new Date(localISO() + 'T00:00:00')) / 864e5);
const relTime = ts => {
  if (!ts) return '';
  const m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} hr ago`;
  const d = Math.round(h / 24);
  return d < 30 ? `${d} day${d > 1 ? 's' : ''} ago` : new Date(ts).toLocaleDateString();
};
const isEmail = s => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
const sameEmail = (a, b) => String(a).toLowerCase() === String(b).toLowerCase();
const icons = () => feather.replace({ 'stroke-width': 1.9 });
const cssVar = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const groupColorVar = g => `--g-${g}`;
const recLabel = p => p.bbaId || 'No BBA ID';
const treated = p => VEIN_KEYS.filter(vk => p[`${vk}_proc`] && p[`${vk}_proc`] !== 'None');
const isAdmin = () => state.role === 'admin';
const lsGet = k => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { /* ignore */ } };
const lsDel = k => { try { localStorage.removeItem(k); } catch { /* ignore */ } };

/* ============================================================
   State
   ============================================================ */
const state = {
  user: null, role: 'staff', patients: [], surgeons: [], settings: {},
  events: [], notif: { readAllAt: 0, read: {} },
  view: 'dashboard', search: '', chart: null, users: null
};
let config = null, auth = null, devEmail = null, entered = false;
let lastSync = 0, syncTimer = null, syncing = false, idleTimer = null;

/* ============================================================
   Toasts
   ============================================================ */
function toast(msg, opts = {}) {
  const el = document.createElement('div');
  el.className = 'toast' + (opts.type === 'error' ? ' error' : '');
  el.innerHTML = `<span>${esc(msg)}</span>`;
  if (opts.action) {
    const b = document.createElement('button');
    b.textContent = opts.action.label;
    b.onclick = () => { el.remove(); opts.action.run(); };
    el.appendChild(b);
  }
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), opts.duration || (opts.type === 'error' ? 7000 : 4500));
}

/* ============================================================
   API
   ============================================================ */
class ApiError extends Error {
  constructor(code, message, status, data) { super(message); this.code = code; this.status = status; this.data = data; }
}
async function idToken() {
  if (devEmail) return 'dev:' + devEmail;
  if (!auth?.currentUser) throw new ApiError('signed_out', 'Sign in to continue.');
  return auth.currentUser.getIdToken();
}
async function api(method, path, body) {
  let token;
  try { token = await idToken(); }
  catch (e) { sessionEnded('Your session ended. Sign in again.'); throw new ApiError('signed_out', 'Sign in to continue.'); }
  let res;
  try {
    res = await fetch('/api' + path, {
      method,
      headers: { Authorization: 'Bearer ' + token, ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined
    });
  } catch (e) {
    setSync('offline');
    throw new ApiError('offline', 'Can’t reach the server. Check your internet connection; nothing was saved.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401) sessionEnded(data.message || 'Your session ended. Sign in again.');
    if (res.status === 403 && data.error === 'not_authorized') denied(data.message);
    throw new ApiError(data.error || 'error', data.message || 'The server couldn’t complete that request.', res.status, data);
  }
  setSync('ok');
  return data;
}
const fail = e => { if (!['signed_out', 'not_authorized'].includes(e.code)) toast(e.message, { type: 'error' }); };

function setSync(status) {
  const el = $('#syncStatus');
  if (!el) return;
  if (status === 'offline') { el.textContent = 'Offline: changes can’t be saved'; el.style.color = 'var(--danger)'; }
  else { el.textContent = 'All changes saved'; el.style.color = ''; }
}

function upsert(p) {
  const i = state.patients.findIndex(x => x.id === p.id);
  if (p.deleted) { if (i !== -1) state.patients.splice(i, 1); return; }
  if (i === -1) state.patients.push(p); else state.patients[i] = p;
}
function mergePatients(list) {
  let changed = false;
  list.forEach(p => {
    const cur = state.patients.find(x => x.id === p.id);
    if (p.deleted ? !!cur : (!cur || cur.updatedAt !== p.updatedAt)) { upsert(p); changed = true; }
  });
  return changed;
}

/* ============================================================
   Shared notifications
   Every add / update / approval creates an event on the server. Each user has their own
   read markers (also on the server), so badges follow them to any computer.
   ============================================================ */
const EVENT_INFO = {
  approved: { label: 'Prior authorization approved', icon: 'check-circle', tone: 'ok' },
  added: { label: 'New record added', icon: 'plus-circle', tone: 'accent' },
  updated: { label: 'Record updated', icon: 'edit-2', tone: 'accent' },
  moved: { label: 'Moved to another tab', icon: 'corner-up-right', tone: 'accent' },
  restored: { label: 'Record restored', icon: 'rotate-ccw', tone: 'accent' },
  deleted: { label: 'Record deleted', icon: 'trash-2', tone: 'danger' }
};
const FIELD_NAMES = {
  name: 'Patient name', bbaId: 'BBA ID', notes: 'Notes', surgeon: 'Surgeon', insurance: 'Insurance', location: 'Location',
  datePromo: 'Date promo', ivVanquish: 'IV or Vanquish', usDate: 'US date', paStatus: 'Auth status', category: 'Tab',
  initialUsStatus: 'Initial U/S', initialUsDate: 'Initial U/S date', poNewVeinsFlag: 'New veins', poNewVeins: 'New veins details'
};
function fieldName(k) {
  if (FIELD_NAMES[k]) return FIELD_NAMES[k];
  const m = MILESTONES.find(x => k === x.k || k === x.k + 'Done');
  if (m) return k.endsWith('Done') ? `${m.label} done` : `${m.label} date`;
  const v = k.match(/^([rl])_([a-z]+)_(proc|units|post)$/);
  if (v) return `${v[1].toUpperCase()} ${v[2].toUpperCase()} ${{ proc: 'procedure', units: 'units', post: 'POST AB US' }[v[3]]}`;
  return k;
}
const fmtWhen = ts => new Date(ts).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
const isUnread = e => !sameEmail(e.by, state.user) && e.at > (state.notif.readAllAt || 0) && !state.notif.read[e.id];

// Unread events grouped per record: approvals separately from other changes
function unreadGroups() {
  const groups = new Map();
  for (const e of state.events) {
    if (!isUnread(e)) continue;
    const kind = e.type === 'approved' ? 'approved' : 'update';
    const key = e.patientId + '|' + kind;
    if (!groups.has(key)) groups.set(key, { key, kind, patientId: e.patientId, events: [] });
    groups.get(key).events.push(e);
  }
  return [...groups.values()].map(g => {
    g.events.sort((a, b) => b.at - a.at);
    g.latest = g.events[0];
    const live = state.patients.find(p => p.id === g.patientId);
    g.category = live ? live.category : g.latest.category;
    g.bbaId = (live && live.bbaId) || g.latest.bbaId || '';
    return g;
  }).sort((a, b) => b.latest.at - a.latest.at);
}
function describe(g) {
  const e = g.latest;
  if (g.kind === 'approved') return EVENT_INFO.approved.label;
  if (e.type === 'moved') return `Moved from ${e.from || 'another tab'} to ${e.category}`;
  if (e.type === 'updated') {
    const fields = [...new Set(g.events.filter(x => x.type === 'updated').flatMap(x => x.fields || []))].map(fieldName);
    const more = g.events.length > 1 ? ` (${g.events.length} changes)` : '';
    return fields.length ? `Updated: ${fields.slice(0, 3).join(', ')}${fields.length > 3 ? ` and ${fields.length - 3} more` : ''}${more}` : `Record updated${more}`;
  }
  return (EVENT_INFO[e.type] || EVENT_INFO.updated).label;
}
function groupsByTab() {
  const out = {};
  unreadGroups().forEach(g => {
    const t = (out[g.category] ||= { n: 0, approved: false });
    t.n++; if (g.kind === 'approved') t.approved = true;
  });
  return out;
}
function rowPill(p) {
  const gs = unreadGroups().filter(g => g.patientId === p.id);
  if (!gs.length) return '';
  if (gs.some(g => g.kind === 'approved')) return '<span class="row-pill ok" title="Newly approved">Approved</span>';
  const t = gs[0].latest.type;
  return `<span class="row-pill" title="${esc(describe(gs[0]))} by ${esc(gs[0].latest.by)}">${t === 'added' ? 'New' : 'Updated'}</span>`;
}
function notifItem(g, compact) {
  const info = EVENT_INFO[g.kind === 'approved' ? 'approved' : g.latest.type] || EVENT_INFO.updated;
  return `<li style="border-color: var(--line)"><button class="notif-item ${compact ? 'px-0' : ''}" data-notif="${esc(g.key)}">
    <span class="notif-ic ${info.tone}"><i data-feather="${info.icon}"></i></span>
    <span class="min-w-0 flex-1">
      <span class="block font-semibold">${g.bbaId ? esc(g.bbaId) : '<span class="italic font-normal text-muted">No BBA ID</span>'} <span class="font-normal text-muted text-[12.5px]">· ${esc(g.category)}</span></span>
      <span class="block text-[13px]">${esc(describe(g))}</span>
      <span class="block text-muted text-[12px]">${esc(fmtWhen(g.latest.at))} by ${esc(g.latest.by)}</span>
    </span></button></li>`;
}
function renderBell() {
  const gs = unreadGroups();
  const dot = $('#bellCount');
  dot.textContent = gs.length > 99 ? '99+' : String(gs.length);
  dot.hidden = gs.length === 0;
  dot.classList.toggle('ok', gs.some(g => g.kind === 'approved'));
  $('#bellBtn').setAttribute('aria-label', gs.length ? `${gs.length} unread notification${gs.length === 1 ? '' : 's'}` : 'No unread notifications');
  document.title = (gs.length ? `(${gs.length}) ` : '') + 'Vein Pre-Authorization & Treatment Tracker';
  const panel = $('#bellPanel');
  if (panel.hidden) return;
  const appr = gs.filter(g => g.kind === 'approved'), upd = gs.filter(g => g.kind !== 'approved');
  panel.innerHTML = `
    <div class="flex items-center justify-between px-4 py-3 border-b" style="border-color: var(--line)">
      <span class="font-semibold">Notifications</span>
      ${gs.length ? '<button class="text-[12.5px] font-semibold" style="color: var(--accent)" data-mark-all>Mark all as read</button>' : ''}
    </div>
    <div class="max-h-[420px] overflow-y-auto thin-scroll">
      ${gs.length ? `
        ${appr.length ? `<div class="px-4 pt-3 text-[12px] font-semibold text-muted">Approvals</div><ul class="divide-y">${appr.map(g => notifItem(g)).join('')}</ul>` : ''}
        ${upd.length ? `<div class="px-4 pt-3 text-[12px] font-semibold text-muted">Added or changed by other staff</div><ul class="divide-y">${upd.map(g => notifItem(g)).join('')}</ul>` : ''}`
      : '<p class="px-4 py-6 text-muted text-[13px]">You’re all caught up. Approvals and changes made by other staff will appear here.</p>'}
    </div>`;
  icons();
}
function closeBell() { $('#bellPanel').hidden = true; $('#bellBtn').setAttribute('aria-expanded', 'false'); }

function mergeNotif(n) {
  if (!n) return;
  const readAllAt = Math.max(state.notif.readAllAt || 0, n.readAllAt || 0);
  const read = { ...(n.read || {}), ...state.notif.read };
  for (const [id, at] of Object.entries(read)) if (at <= readAllAt) delete read[id];
  state.notif = { readAllAt, read };
}
function mergeEvents(list) {
  const known = new Set(state.events.map(e => e.id));
  const fresh = list.filter(e => !known.has(e.id));
  if (fresh.length) {
    const cutoff = Date.now() - 30 * 864e5;
    state.events = [...fresh, ...state.events].filter(e => e.at > cutoff).sort((a, b) => b.at - a.at).slice(0, 400);
  }
  return fresh;
}
async function markRead(events) {
  const items = events.filter(isUnread).map(e => ({ id: e.id, at: e.at }));
  if (!items.length) return;
  items.forEach(it => { state.notif.read[it.id] = it.at; });
  render();
  try { const d = await api('POST', '/notifications/read', { items }); mergeNotif(d.notif); }
  catch (e) { fail(e); }
}
async function markAllRead() {
  state.notif = { readAllAt: Date.now(), read: {} };
  render();
  try { const d = await api('POST', '/notifications/read-all'); state.notif = d.notif; render(); }
  catch (e) { fail(e); }
}
function announce(fresh) {
  const mine = fresh.filter(isUnread);
  if (!mine.length) return;
  const appr = mine.filter(e => e.type === 'approved');
  const view = { label: 'View', run: () => { $('#bellPanel').hidden = false; $('#bellBtn').setAttribute('aria-expanded', 'true'); renderBell(); } };
  appr.slice(0, 3).forEach(e => toast(`${e.bbaId || 'A record'} was approved by ${e.by}`, { action: view, duration: 8000 }));
  const others = mine.length - appr.length;
  if (others) toast(`${others} update${others === 1 ? '' : 's'} from other staff`, { action: view });
}

let lastHiddenSync = 0;
async function syncNow() {
  if (syncing || !entered) return;
  if (document.hidden) { if (Date.now() - lastHiddenSync < 60000) return; lastHiddenSync = Date.now(); }
  syncing = true;
  try {
    const d = await api('GET', `/sync?since=${lastSync}`);
    lastSync = d.serverTime;
    const changed = mergePatients(d.patients);
    const fresh = mergeEvents(d.events || []);
    const before = JSON.stringify(state.notif);
    mergeNotif(d.notif);
    if (fresh.length || before !== JSON.stringify(state.notif)) { render(); announce(fresh); }
    const cfgChanged = JSON.stringify([d.surgeons, d.settings]) !== JSON.stringify([state.surgeons, state.settings]);
    state.surgeons = d.surgeons; state.settings = d.settings;
    if (changed || cfgChanged) render();
  } catch (e) { /* status already shown */ }
  finally { syncing = false; }
}

/* ============================================================
   Sign-in (Google Cloud Identity Platform, email link)
   ============================================================ */
const EMAIL_KEY = 'vct_email_for_signin';
const ACTIVE_KEY = 'vct_last_active';

function showSignin(step, msg) {
  $('#loading').hidden = true;
  $('#app').hidden = true;
  $('#login').hidden = false;
  ['signinRequest', 'signinSent', 'signinConfirm', 'signinDenied', 'signinBusy'].forEach(id => $('#' + id).hidden = true);
  $({ request: '#signinRequest', sent: '#signinSent', confirm: '#signinConfirm', denied: '#signinDenied', busy: '#signinBusy' }[step]).hidden = false;
  $('#devLogin').hidden = !config?.devAuth;
  if (step === 'request') {
    const err = $('#loginError');
    err.textContent = msg || ''; err.hidden = !msg;
    setTimeout(() => $('#loginEmail').focus(), 0);
  }
  if (step === 'denied') $('#deniedMsg').textContent = msg || '';
  icons();
}

async function requestLink(email) {
  email = email.trim();
  const err = $('#loginError');
  if (!isEmail(email)) { err.textContent = 'Enter your full work email address.'; err.hidden = false; return; }
  const btn = $('#loginBtn');
  btn.disabled = true;
  try {
    await sendSignInLinkToEmail(auth, email, { url: location.origin + '/', handleCodeInApp: true });
    lsSet(EMAIL_KEY, email);
    $('#sentTo').textContent = email;
    showSignin('sent');
  } catch (e) {
    err.textContent = e.code === 'auth/too-many-requests'
      ? 'Too many sign-in requests. Wait a few minutes, then try again.'
      : e.code === 'auth/invalid-email' ? 'That email address isn’t valid.'
      : 'The sign-in email couldn’t be sent. Check your connection and try again.';
    err.hidden = false;
  } finally { btn.disabled = false; }
}

async function completeLink(email) {
  showSignin('busy');
  try {
    lsSet(ACTIVE_KEY, String(Date.now())); // before sign-in completes, so the idle check passes
    await signInWithEmailLink(auth, email, location.href);
    lsDel(EMAIL_KEY);
    history.replaceState(null, '', '/');
    // onAuthStateChanged takes it from here
  } catch (e) {
    history.replaceState(null, '', '/');
    showSignin('request', e.code === 'auth/invalid-email'
      ? 'That email doesn’t match the one the link was sent to. Request a new link.'
      : 'This sign-in link has expired or was already used. Request a new one.');
  }
}

function denied(msg) {
  stopSession();
  if (auth) fbSignOut(auth).catch(() => {});
  devEmail = null; sessionStorage.removeItem('vct_dev_email');
  showSignin('denied', msg || 'This email is not on the authorized list. Ask an administrator to add it.');
}

function sessionEnded(msg) {
  if (!entered) return;
  stopSession();
  showSignin('request', msg);
}

async function signOut(msg) {
  stopSession();
  devEmail = null; sessionStorage.removeItem('vct_dev_email');
  lsDel(ACTIVE_KEY);
  if (auth) await fbSignOut(auth).catch(() => {});
  showSignin('request', msg);
}

function stopSession() {
  entered = false;
  clearInterval(syncTimer); clearInterval(idleTimer);
  closeModal();
  // Clear patient data from memory and the page
  state.user = null; state.patients = []; state.users = null; state.events = []; state.notif = { readAllAt: 0, read: {} };
  closeBell(); document.title = 'Vein Pre-Authorization & Treatment Tracker';
  if (state.chart) { state.chart.destroy(); state.chart = null; }
  ['#tbody', '#upcoming', '#recent', '#auditBody', '#userList'].forEach(s => { const el = $(s); if (el) el.innerHTML = ''; });
}

async function enterApp() {
  if (entered) return;
  entered = true;
  $('#login').hidden = true;
  $('#loading').hidden = false;
  let d;
  try { d = await api('GET', '/bootstrap'); }
  catch (e) {
    entered = false;
    if (e.code === 'offline') { $('#loading').textContent = 'Can’t reach the server. Check your connection, then reload the page.'; }
    return;
  }
  state.user = d.me.email; state.role = d.me.role;
  state.patients = d.patients; state.surgeons = d.surgeons; state.settings = d.settings;
  state.events = d.events || []; state.notif = d.notif || { readAllAt: 0, read: {} };
  lastSync = d.serverTime;
  $('#loading').hidden = true;
  $('#app').hidden = false;
  $('#userEmail').textContent = state.user;
  $('#userInitial').textContent = state.user[0].toUpperCase();
  $('#userRole').textContent = isAdmin() ? 'Administrator' : 'Staff';
  if (ADMIN.find(a => a.key === state.view)?.adminOnly && !isAdmin()) state.view = 'dashboard';
  render();
  syncTimer = setInterval(syncNow, SYNC_MS);
  startIdleWatch();
}

function startIdleWatch() {
  const limit = (config.idleMinutes || 30) * 60000;
  lsSet(ACTIVE_KEY, String(Date.now()));
  idleTimer = setInterval(() => {
    const last = Number(lsGet(ACTIVE_KEY)) || Date.now();
    if (Date.now() - last > limit) signOut(`You were signed out after ${config.idleMinutes || 30} minutes without activity.`);
  }, 30000);
}
let lastMark = 0;
['pointerdown', 'keydown', 'wheel', 'touchstart'].forEach(ev => document.addEventListener(ev, () => {
  if (!entered) return;
  const t = Date.now();
  if (t - lastMark > 20000) { lastMark = t; lsSet(ACTIVE_KEY, String(t)); }
}, { passive: true }));

/* ============================================================
   Navigation & layout
   ============================================================ */
function viewKind() { return TAB[state.view] ? 'list' : state.view; }

function navigate(view) {
  state.view = view;
  state.search = '';
  $('#search').value = '';
  closeSidebar();
  render();
  $('#main').scrollTop = 0;
  if (view === 'users') loadUsers();
  if (view === 'activity') loadAudit();
}

function openSidebar() { $('#sidebar').classList.remove('-translate-x-full'); $('#scrim').hidden = false; }
function closeSidebar() { $('#sidebar').classList.add('-translate-x-full'); $('#scrim').hidden = true; }

function renderSidebar() {
  const count = k => state.patients.filter(p => p.category === k).length;
  const byTab = groupsByTab();
  const item = (key, label, icon, extra = '', color = '') => `
    <button class="nav-item" data-nav="${esc(key)}" ${state.view === key ? 'aria-current="page"' : ''} ${color ? `style="--nav-color: var(${color})"` : ''}>
      <i data-feather="${icon}"></i><span class="truncate">${esc(label)}</span>${extra}
    </button>`;
  let html = `<div class="pt-2">${item('dashboard', 'Dashboard', 'bar-chart-2')}</div>`;
  Object.entries(GROUPS).forEach(([g, gl]) => {
    html += `<div class="nav-group">${gl}</div>`;
    TABS.filter(t => t.group === g).forEach(t => {
      const b = byTab[t.key];
      const badge = b ? `<span class="nbadge ${b.approved ? 'ok' : ''}" title="${b.n} unread: ${b.approved ? 'includes new approvals' : 'records added or changed'}">${b.n}</span>` : '';
      html += item(t.key, t.key, t.icon, `${badge}<span class="count">${count(t.key)}</span>`, groupColorVar(g));
    });
  });
  html += `<div class="nav-group">Administration</div>`;
  ADMIN.filter(a => !a.adminOnly || isAdmin()).forEach(a => {
    const extra = a.key === 'surgeons' ? `<span class="count">${state.surgeons.length}</span>` : '';
    html += item(a.key, a.label, a.icon, extra);
  });
  $('#nav').innerHTML = html;
  document.querySelectorAll('[data-practice]').forEach(el => el.textContent = state.settings.practiceName || config?.practiceName || '');
}

function renderHeader() {
  const kind = viewKind();
  const t = TAB[state.view];
  const admin = ADMIN.find(a => a.key === state.view);
  $('#viewTitle').textContent = t ? t.key : admin ? admin.label : 'Dashboard';
  $('#viewSub').textContent = t ? t.blurb : admin ? admin.blurb : `Pre-authorization and treatment overview, ${new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}`;
  $('#searchWrap').hidden = kind !== 'list';
  $('#addBtn').hidden = kind !== 'list';
}

function render() {
  if (!state.user) return;
  document.body.classList.toggle('compact', lsGet('vct_compact') === '1');
  renderSidebar();
  renderHeader();
  renderBell();
  const kind = viewKind();
  ['dashboard', 'list', 'surgeons', 'users', 'activity', 'settings'].forEach(v => $('#view-' + v).hidden = kind !== v);
  if (kind === 'dashboard') renderDashboard();
  if (kind === 'list') renderList();
  if (kind === 'surgeons') renderSurgeons();
  if (kind === 'users') renderUsers();
  if (kind === 'settings') renderSettings();
  icons();
}

/* ============================================================
   Dashboard
   ============================================================ */
function openMilestones() {
  const out = [];
  state.patients.filter(p => p.category === 'PO Vein FU').forEach(p => {
    MILESTONES.forEach(m => {
      if (p[m.k] && !p[m.k + 'Done']) out.push({ p, m, date: p[m.k], diff: daysFromToday(p[m.k]) });
    });
  });
  return out.sort((a, b) => a.date.localeCompare(b.date));
}

function renderDashboard() {
  const P = state.patients;
  const by = k => P.filter(p => p.category === k).length;
  const active = ['Promo', 'Procter Pay Attention', 'Dr. Procter', 'Dr. Danthuluri'].reduce((s, k) => s + by(k), 0);
  const po = by('PO Vein FU');
  const overdue = openMilestones().filter(x => x.diff < 0).length;
  const denied = by('PA DENIED'), notInt = by('Not Interested Now or excluded');

  const byTab = groupsByTab();
  const badgeFor = tabs => {
    const hits = tabs.map(k => byTab[k]).filter(Boolean);
    const n = hits.reduce((a, b) => a + b.n, 0);
    return n ? `<span class="kpi-badge ${hits.some(h => h.approved) ? 'ok' : ''}">${n} new</span>` : '';
  };
  const KPI_TABS = {
    total: TABS.map(t => t.key),
    active: ['Promo', 'Procter Pay Attention', 'Dr. Procter', 'Dr. Danthuluri'],
    po: ['PO Vein FU'],
    closed: ['PA DENIED', 'Not Interested Now or excluded']
  };
  const kpi = (n, t, s, color, nav, tabs) => `
    <button class="kpi hover:bg-sunken" ${nav ? `data-nav="${esc(nav)}"` : tabs ? 'data-open-bell' : 'disabled style="cursor:default"'}>
      ${badgeFor(tabs || [])}
      <div class="bar" style="background: var(${color})"></div>
      <div class="n">${n}</div><div class="t">${t}</div><div class="s">${s}</div>
    </button>`;
  $('#kpis').innerHTML =
    kpi(P.length, 'Total patients', `Across ${TABS.length} tabs`, '--accent', null, KPI_TABS.total) +
    kpi(active, 'Active workflows', `${by('Dr. Procter') + by('Dr. Danthuluri')} in surgeon queues`, '--g-surgeon', 'Dr. Procter', KPI_TABS.active) +
    kpi(po, 'Post-op follow-ups', overdue ? `<span style="color: var(--danger); font-weight:600">${overdue} milestone${overdue > 1 ? 's' : ''} overdue</span>` : 'No overdue milestones', '--g-postop', 'PO Vein FU', KPI_TABS.po) +
    kpi(denied + notInt, 'Denied or excluded', `${denied} denied, ${notInt} not interested`, '--g-closed', 'PA DENIED', KPI_TABS.closed);

  const gs = unreadGroups();
  const appr = gs.filter(g => g.kind === 'approved'), upd = gs.filter(g => g.kind !== 'approved');
  $('#whatsNewMeta').textContent = gs.length ? `${gs.length} unread` : '';
  $('#whatsNewMarkAll').hidden = !gs.length;
  $('#newApprovals').innerHTML = appr.length ? appr.slice(0, 5).map(g => notifItem(g, true)).join('') + (appr.length > 5 ? `<li class="py-2 text-[12.5px]"><button data-open-bell style="color: var(--accent)" class="font-semibold">See all ${appr.length}</button></li>` : '')
    : '<li class="py-3 text-muted text-[13px]">No new approvals.</li>';
  $('#newUpdates').innerHTML = upd.length ? upd.slice(0, 5).map(g => notifItem(g, true)).join('') + (upd.length > 5 ? `<li class="py-2 text-[12.5px]"><button data-open-bell style="color: var(--accent)" class="font-semibold">See all ${upd.length}</button></li>` : '')
    : '<li class="py-3 text-muted text-[13px]">Nothing new from other staff.</li>';

  renderChart();

  const up = openMilestones().slice(0, 7);
  $('#upcoming').innerHTML = up.length ? up.map(({ p, m, date, diff }) => {
    const chip = diff < 0 ? `<span class="chip danger">${-diff} day${diff < -1 ? 's' : ''} overdue</span>`
      : diff === 0 ? `<span class="chip warn">Today</span>`
      : diff <= 14 ? `<span class="chip warn">In ${diff} day${diff > 1 ? 's' : ''}</span>`
      : `<span class="chip">${esc(fmtDate(date))}</span>`;
    return `<li style="border-color: var(--line)"><button class="w-full text-left py-2.5 flex items-center gap-3" data-edit="${esc(p.id)}">
      <div class="min-w-0 flex-1"><div class="font-semibold truncate">${esc(recLabel(p))}</div>
      <div class="text-muted text-[12.5px]">${m.label}, ${esc(fmtDate(date))}</div></div>${chip}</button></li>`;
  }).join('') : `<li class="py-6 text-muted text-[13px]">No open milestones. Add dates on PO Vein FU records to see them here.</li>`;

  const counts = { RFA: 0, Varithena: 0, Venaseal: 0 };
  let postDone = 0, segs = 0;
  P.forEach(p => treated(p).forEach(vk => {
    const pr = p[`${vk}_proc`]; if (counts[pr] !== undefined) counts[pr]++;
    segs++; if (p[`${vk}_post`] === 'Completed') postDone++;
  }));
  const max = Math.max(1, ...Object.values(counts));
  const pVar = { RFA: '--p-rfa', Varithena: '--p-varithena', Venaseal: '--p-venaseal' };
  $('#procMix').innerHTML = Object.entries(counts).map(([k, v]) => `
    <div><div class="flex justify-between text-[13px]"><span class="font-medium">${k}</span><span class="font-semibold">${v}</span></div>
    <div class="h-2 rounded-full mt-1" style="background: var(--sunken)"><div class="h-2 rounded-full" style="width:${(v / max) * 100}%; background: var(${pVar[k]})"></div></div></div>`).join('') +
    `<p class="text-muted text-[12.5px] pt-2 border-t" style="border-color: var(--line)">POST AB US completed on ${postDone} of ${segs} segment${segs === 1 ? '' : 's'}.</p>`;

  const recent = [...P].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)).slice(0, 6);
  $('#recent').innerHTML = recent.length ? recent.map(p => `
    <li style="border-color: var(--line)"><button class="w-full text-left py-2.5 flex items-center gap-3 flex-wrap" data-edit="${esc(p.id)}">
      <span class="swatch" style="background: var(${groupColorVar(TAB[p.category]?.group || 'intake')})"></span>
      <span class="font-semibold">${esc(recLabel(p))}</span>
      <span class="text-muted text-[13px]">${esc(p.category)}</span>
      <span class="ml-auto text-muted text-[12.5px]">${esc(relTime(p.updatedAt))}${p.updatedBy ? ', ' + esc(p.updatedBy) : ''}</span>
    </button></li>`).join('') : `<li class="py-6 text-muted text-[13px]">No records yet. Open a tab and choose Add record.</li>`;
}

function chartLabel(k) {
  if (k.length <= 14) return k;
  const lines = []; let cur = '';
  k.split(' ').forEach(w => { if ((cur + ' ' + w).trim().length > 16) { lines.push(cur.trim()); cur = w; } else cur += ' ' + w; });
  if (cur.trim()) lines.push(cur.trim());
  return lines;
}

function renderChart() {
  const data = TABS.map(t => state.patients.filter(p => p.category === t.key).length);
  if (state.chart) { state.chart.data.datasets[0].data = data; state.chart.update(); return; }
  const muted = cssVar('--muted'), line = cssVar('--line');
  state.chart = new Chart($('#chart'), {
    type: 'bar',
    data: {
      labels: TABS.map(t => chartLabel(t.key)),
      datasets: [{ label: 'Patients', data, backgroundColor: TABS.map(t => cssVar(groupColorVar(t.group))), borderRadius: 4, maxBarThickness: 56 }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 350 },
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { title: items => TABS[items[0].dataIndex].key, label: i => ` ${i.raw} patient${i.raw === 1 ? '' : 's'}` } }
      },
      scales: {
        y: { beginAtZero: true, ticks: { precision: 0, color: muted }, grid: { color: line }, border: { display: false } },
        x: { ticks: { color: muted, font: { size: 11.5 }, maxRotation: 0, autoSkip: false }, grid: { display: false } }
      },
      onClick: (e, els) => { if (els.length) navigate(TABS[els[0].index].key); },
      onHover: (e, els) => { e.native.target.style.cursor = els.length ? 'pointer' : 'default'; }
    }
  });
}

/* ============================================================
   Patient list
   ============================================================ */
const dash = v => (v === undefined || v === null || v === '') ? '<span class="text-muted">–</span>' : esc(v);
const idCell = p => `<div class="font-semibold whitespace-nowrap">${p.bbaId ? esc(p.bbaId) : '<span class="text-muted italic font-normal">No BBA ID</span>'}${rowPill(p)}</div>`;
const paCell = p => {
  const s = p.paStatus || '';
  if (!s) return dash();
  const cls = s === 'Approved' ? 'ok' : s === 'Denied' ? 'danger' : 'warn';
  return `<span class="chip ${cls}">${esc(s)}</span>`;
};
const usCell = p => {
  const s = p.initialUsStatus || '';
  if (!s && !p.initialUsDate) return dash();
  const cls = s === 'Reviewed' || s === 'Received' ? 'ok' : s === 'Requested' ? 'warn' : '';
  return `${s ? `<span class="chip ${cls}">${esc(s)}</span>` : ''}${p.initialUsDate ? `<div class="text-muted text-[12px] mt-0.5 whitespace-nowrap">${esc(fmtDate(p.initialUsDate))}</div>` : ''}`;
};
const dateCell = d => d ? `<span class="whitespace-nowrap">${esc(fmtDate(d))}</span>` : dash();
const notesCell = p => p.notes ? `<div class="notes-cell" title="${esc(p.notes)}">${esc(p.notes)}</div>` : dash();
const hasUnits = u => u !== '' && u != null;

const VEIN_HEAD = `<div class="vg" aria-hidden="true"><span></span>${VEINS.map(v => `<span class="ax">${v.label}</span>`).join('')}</div><div class="mt-0.5">Vein map</div>`;
function veinGlyph(p) {
  const desc = [];
  const rows = SIDES.map(s => `<span class="side">${s.label[0]}</span>` + VEINS.map(v => {
    const vk = `${s.k}_${v.k}`, pr = p[`${vk}_proc`], u = p[`${vk}_units`];
    const on = pr && pr !== 'None';
    if (on) desc.push(`${s.label} ${v.label}: ${pr}${hasUnits(u) ? `, ${u} units` : ''}${p[`${vk}_post`] ? `, POST AB US ${p[`${vk}_post`]}` : ''}`);
    return `<span class="c" ${on ? `data-p="${esc(pr)}"` : ''} title="${esc(`${s.label} ${v.label}: ${on ? pr : 'None'}${on && hasUnits(u) ? `, ${u} units` : ''}`)}">${on && hasUnits(u) ? esc(u) : ''}</span>`;
  }).join('')).join('');
  return `<div class="vg" role="img" aria-label="${esc(desc.length ? desc.join('; ') : 'No veins planned')}">${rows}</div>`;
}
function postSummary(p) {
  const t = treated(p);
  if (!t.length) return dash();
  const done = t.filter(vk => p[`${vk}_post`] === 'Completed').length;
  const cls = done === t.length ? 'ok' : done ? 'warn' : '';
  return `<span class="chip ${cls}">${done} of ${t.length} done</span>`;
}
function msCell(p, k) {
  const date = p[k], done = !!p[k + 'Done'];
  if (!date && !done) return dash();
  let status = 'scheduled';
  if (done) status = 'done';
  else { const d = daysFromToday(date); status = d < 0 ? 'overdue' : d <= 14 ? 'soon' : 'scheduled'; }
  const label = date ? fmtDate(date) : 'Done';
  return `<button class="ms ms-${status}" data-ms="${k}" data-id="${esc(p.id)}" aria-pressed="${done}" title="${done ? 'Completed. Select to mark not done.' : 'Select to mark completed.'}"><i data-feather="${done ? 'check-circle' : 'circle'}"></i>${esc(label)}</button>`;
}

function columns(type) {
  const base = [{ h: 'BBA ID', c: idCell }];
  if (type === 'promo') return [...base,
    { h: 'Insurance', c: p => dash(p.insurance) },
    { h: 'Location', c: p => p.location ? `<span class="chip accent">${esc(p.location)}</span>` : dash() },
    { h: 'Date promo', c: p => dateCell(p.datePromo) },
    { h: 'IV or Vanquish', c: p => dash(p.ivVanquish) },
    { h: 'US date', c: p => dateCell(p.usDate) },
    { h: 'Notes', c: notesCell }];
  const clin = [...base,
    { h: 'Surgeon', c: p => dash(p.surgeon) },
    { h: VEIN_HEAD, c: veinGlyph, raw: true }];
  if (type === 'clinical') return [...clin, { h: 'Auth status', c: paCell }, { h: 'Initial U/S', c: usCell }, { h: 'POST AB US', c: postSummary }, { h: 'Notes', c: notesCell }];
  return [...clin,
    { h: 'Auth status', c: paCell },
    { h: 'Initial U/S', c: usCell },
    ...MILESTONES.map(m => ({ h: m.label, c: p => msCell(p, m.k) })),
    { h: 'New veins', c: p => p.poNewVeinsFlag ? `<span class="chip warn" title="${esc(p.poNewVeins || '')}">Yes</span>` : dash() },
    { h: 'Notes', c: notesCell }];
}

function rowsFor(tabKey) {
  const q = state.search.toLowerCase().trim();
  return state.patients
    .filter(p => p.category === tabKey)
    .filter(p => !q || [p.bbaId, p.name, p.insurance, p.surgeon, p.notes, p.location, p.poNewVeins, p.paStatus, p.initialUsStatus]
      .some(v => String(v || '').toLowerCase().includes(q)))
    .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
}

function renderList() {
  const tab = TAB[state.view];
  const cols = columns(tab.type);
  const rows = rowsFor(tab.key);
  const total = state.patients.filter(p => p.category === tab.key).length;

  $('#listMeta').textContent = state.search
    ? `${rows.length} of ${total} record${total === 1 ? '' : 's'} match “${state.search}”`
    : `${total} record${total === 1 ? '' : 's'}, most recently updated first`;
  $('#legend').innerHTML = tab.type === 'promo' ? '' :
    PROCS.slice(1).map(p => `<span class="inline-flex items-center gap-1.5"><span class="swatch" style="background: var(--p-${p.toLowerCase()})"></span>${p}</span>`).join('') +
    `<span>Numbers are units</span>`;

  $('#thead').innerHTML = `<tr>${cols.map(c => `<th>${c.raw ? c.h : esc(c.h)}</th>`).join('')}<th class="text-right"><span class="sr-only">Actions</span></th></tr>`;
  $('#tbody').innerHTML = rows.map(p => `
    <tr data-row="${esc(p.id)}">
      ${cols.map(c => `<td>${c.c(p)}</td>`).join('')}
      <td class="text-right whitespace-nowrap">
        <button class="icon-btn" data-notes="${esc(p.id)}" aria-label="Edit notes" title="Notes"><i data-feather="file-text"></i></button>
        <button class="icon-btn" data-move="${esc(p.id)}" aria-label="Move to another tab" title="Move to tab"><i data-feather="corner-up-right"></i></button>
        <button class="icon-btn" data-edit="${esc(p.id)}" aria-label="Edit record" title="Edit"><i data-feather="edit-2"></i></button>
        <button class="icon-btn danger" data-del="${esc(p.id)}" aria-label="Delete record" title="Delete"><i data-feather="trash-2"></i></button>
      </td>
    </tr>`).join('');

  const empty = $('#empty');
  empty.hidden = rows.length > 0;
  $('#thead').parentElement.hidden = rows.length === 0;
  if (!rows.length) {
    empty.innerHTML = state.search
      ? `<p class="font-semibold">No records in ${esc(tab.key)} match “${esc(state.search)}”.</p>
         <p class="text-muted mt-1">Check the spelling or search by BBA ID.</p>
         <button class="btn btn-quiet mt-4" data-clear-search>Clear search</button>`
      : `<p class="font-semibold">${esc(tab.key)} has no records yet.</p>
         <p class="text-muted mt-1">${tab.nameRequired ? 'Each record needs a BBA ID.' : 'You can save a record without a BBA ID.'}</p>
         <button class="btn btn-primary mt-4" data-add><i data-feather="plus"></i>Add record</button>`;
  }
}

/* ============================================================
   Record form
   ============================================================ */
const field = (label, inner, opts = {}) =>
  `<label class="block ${opts.cls || ''}"><span class="lbl">${label}${opts.req ? ' <span class="req">*</span>' : opts.opt ? ' <span class="opt">(optional)</span>' : ''}</span>${inner}${opts.err ? `<div class="err" data-err="${opts.err}" hidden></div>` : ''}</label>`;
const input = (name, val, type = 'text', extra = '', cls = 'ctl') =>
  `<input name="${name}" type="${type}" value="${esc(val ?? '')}" class="${cls}" ${extra}>`;
function select(name, options, val, extra = '', cls = 'ctl') {
  const opts = options.map(o => typeof o === 'object' ? o : { v: o, l: o || 'Select' });
  const cur = val ?? '';
  if (cur !== '' && !opts.some(o => String(o.v) === String(cur))) opts.push({ v: cur, l: `${cur} (previous value)` });
  return `<select name="${name}" class="${cls}" ${extra}>${opts.map(o => `<option value="${esc(o.v)}" ${String(o.v) === String(cur) ? 'selected' : ''}>${esc(o.l)}</option>`).join('')}</select>`;
}

function veinSchemaEditor(r) {
  const cellsFor = (s, v, mirror) => {
    const vk = `${s.k}_${v.k}`;
    const proc = r[`${vk}_proc`] || 'None';
    const tds = [
      `<td>${select(`${vk}_proc`, PROCS, proc, `data-proc="${esc(proc)}" aria-label="${s.label} ${v.label} procedure"`, 'ctl proc')}</td>`,
      `<td>${input(`${vk}_units`, r[`${vk}_units`], 'number', `min="0" step="0.5" inputmode="decimal" aria-label="${s.label} ${v.label} units"`, 'ctl units')}</td>`,
      `<td>${select(`${vk}_post`, POST_STATUS, r[`${vk}_post`] || '', `aria-label="${s.label} ${v.label} POST AB US"`)}</td>`
    ];
    return (mirror ? tds.reverse() : tds).join('');
  };
  return `
    <div class="flex flex-wrap items-center justify-between gap-2 mb-2">
      <div class="section-h mb-0"><i data-feather="activity"></i>Vein treatment plan</div>
      <div class="flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-muted">
        ${PROCS.slice(1).map(p => `<span class="inline-flex items-center gap-1.5"><span class="swatch" style="background: var(--p-${p.toLowerCase()})"></span>${p}</span>`).join('')}
      </div>
    </div>
    <div class="scroll-x thin-scroll border rounded-lg" style="border-color: var(--line)">
      <table class="vtable">
        <thead>
          <tr style="border-bottom: 1px solid var(--line)">
            <th colspan="3" class="side-h" style="text-align:right">Right leg</th>
            <th class="mid"></th>
            <th colspan="3" class="side-h">Left leg</th>
          </tr>
          <tr>
            <th style="text-align:right">POST AB US</th><th>Units</th><th>Procedure</th>
            <th class="mid">Vein</th>
            <th>Procedure</th><th>Units</th><th>POST AB US</th>
          </tr>
        </thead>
        <tbody>
          ${VEINS.map(v => `<tr>${cellsFor(SIDES[0], v, true)}<td class="mid"><b>${v.label}</b><small>${v.full}</small></td>${cellsFor(SIDES[1], v, false)}</tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

function milestonesEditor(r) {
  return `
    <div class="section-h"><i data-feather="calendar"></i>Post-op follow-up</div>
    <div class="grid sm:grid-cols-2 gap-3">
      ${MILESTONES.map(m => `
        <div class="border rounded-lg p-3" style="border-color: var(--line)">
          <div class="flex items-center justify-between gap-2 mb-2">
            <span class="font-semibold text-[13.5px]">${m.label}</span>
            <label class="flex items-center gap-2 text-[13px]"><input type="checkbox" name="${m.k}Done" ${r[m.k + 'Done'] ? 'checked' : ''}>Completed</label>
          </div>
          ${input(m.k, r[m.k], 'date', `aria-label="${m.label} date"`)}
        </div>`).join('')}
    </div>
    <div class="flex flex-wrap items-center justify-between gap-2 mt-3">
      <span class="text-muted text-[12.5px]">Have a procedure date? Fill all four milestone dates from it.</span>
      <div class="flex items-center gap-2">
        <input type="date" id="procDateHelper" class="ctl" style="width:auto" aria-label="Procedure date">
        <button type="button" class="btn btn-quiet" data-fill-ms>Fill dates</button>
      </div>
    </div>
    <div class="border rounded-lg p-3 mt-3" style="border-color: var(--line)">
      <label class="flex items-center gap-2 font-semibold text-[13.5px] mb-2"><input type="checkbox" name="poNewVeinsFlag" ${r.poNewVeinsFlag ? 'checked' : ''}>New veins to treat</label>
      ${input('poNewVeins', r.poNewVeins, 'text', 'placeholder="Which veins, and what was found" aria-label="New veins details"')}
    </div>`;
}

function formBody(r) {
  const tab = TAB[r.category];
  let html = `
    <div class="grid sm:grid-cols-3 gap-4">
      ${field('Tab', select('category', TABS.map(t => t.key), r.category))}
      ${field('BBA ID', input('bbaId', r.bbaId, 'text', 'autocomplete="off"'), { req: tab.nameRequired, opt: !tab.nameRequired, err: 'bbaId' })}
      ${field('Patient name', input('name', r.name, 'text', 'autocomplete="off"'), { opt: true })}
    </div>`;
  if (tab.type === 'promo') {
    html += `
      <div class="grid sm:grid-cols-3 gap-4 mt-4">
        ${field('Insurance', input('insurance', r.insurance, 'text', 'placeholder="e.g. BCBS, Aetna, Medicare"'))}
        ${field('Location', select('location', LOCATIONS, r.location || state.settings.defaultLocation))}
        ${field('IV or Vanquish', select('ivVanquish', IV_OPTIONS, r.ivVanquish || ''))}
        ${field('Date promo', input('datePromo', r.datePromo, 'date'))}
        ${field('US date', input('usDate', r.usDate, 'date'))}
      </div>`;
  } else {
    html += `<div class="grid sm:grid-cols-3 gap-4 mt-4">
      ${field('Surgeon', select('surgeon', ['', ...state.surgeons], r.surgeon || ''))}
      ${field('Authorization status', select('paStatus', PA_STATUS, r.paStatus || ''))}
      ${r.paStatus === 'Approved' && r.paApprovedAt ? `<div class="text-[12.5px] self-end pb-2" style="color: var(--ok)">Approved ${esc(new Date(r.paApprovedAt).toLocaleDateString())}${r.paApprovedBy ? ' by ' + esc(r.paApprovedBy) : ''}</div>` : '<div></div>'}
      ${field('Initial U/S', select('initialUsStatus', INITIAL_US, r.initialUsStatus || ''))}
      ${field('Initial U/S date', input('initialUsDate', r.initialUsDate, 'date'))}
    </div>`;
    html += `<div class="mt-6">${veinSchemaEditor(r)}</div>`;
    if (tab.type === 'po') html += `<div class="mt-6">${milestonesEditor(r)}</div>`;
  }
  html += `<div class="mt-6">${field('Notes', `<textarea name="notes" class="ctl" placeholder="Authorization status, calls, reminders">${esc(r.notes || '')}</textarea>`)}</div>`;
  return html;
}

function readForm(form) {
  const out = {};
  [...form.elements].forEach(el => {
    if (!el.name) return;
    if (el.type === 'checkbox') out[el.name] = el.checked;
    else if (el.type === 'number') out[el.name] = el.value === '' ? '' : Number(el.value);
    else out[el.name] = el.value.trim();
  });
  return out;
}

let draft = null;
function openRecord(id, presetCategory, focusError) {
  const existing = id ? state.patients.find(p => p.id === id) : null;
  if (id && !existing) return;
  closeBell();
  if (existing) markRead(state.events.filter(e => e.patientId === existing.id));
  const category = presetCategory || existing?.category || state.view;
  draft = existing ? { ...existing, category } : { category, surgeon: '' };
  if (!existing) {
    const t = TAB[category];
    if (t.surgeonMatch) draft.surgeon = state.surgeons.find(s => t.surgeonMatch.test(s)) || '';
    if (t.type === 'promo') draft.location = state.settings.defaultLocation;
  }
  const meta = existing
    ? `Created ${existing.createdAt ? new Date(existing.createdAt).toLocaleDateString() : 'earlier'}. Last updated ${esc(relTime(existing.updatedAt))}${existing.updatedBy ? ' by ' + esc(existing.updatedBy) : ''}.`
    : '';
  showModal(`
    <form id="recordForm" class="modal max-w-[980px]" novalidate>
      <div class="flex items-center justify-between gap-3 px-6 py-4 border-b" style="border-color: var(--line)">
        <div>
          <h2 class="text-[17px] font-bold tracking-tight">${existing ? 'Edit record' : 'Add record'}</h2>
          <p class="text-muted text-[12.5px]" id="formTabNote"></p>
        </div>
        <button type="button" class="icon-btn" data-close aria-label="Close"><i data-feather="x"></i></button>
      </div>
      <div id="conflictBanner" class="mx-6 mt-4 p-3 rounded-lg text-[13px]" style="background: var(--warn-soft); color: var(--warn)" role="alert" hidden></div>
      <div class="px-6 py-5" id="formBody">${formBody(draft)}</div>
      <div class="px-6 py-4 border-t flex flex-wrap items-center justify-between gap-3" style="border-color: var(--line); background: var(--sunken); border-radius: 0 0 12px 12px">
        <p class="text-muted text-[12.5px]">${meta}</p>
        <div class="flex gap-2 ml-auto">
          <button type="button" class="btn btn-quiet" data-close>Cancel</button>
          <button type="submit" class="btn btn-primary" id="saveRecordBtn"><i data-feather="check"></i>Save record</button>
        </div>
      </div>
    </form>`);
  updateFormNote();
  const form = $('#recordForm');
  form.dataset.id = id || '';
  form.dataset.base = existing ? String(existing.updatedAt) : '';
  if (focusError) showNameError(form);
  else form.querySelector('[name="bbaId"]').focus();
}

function updateFormNote() {
  const form = $('#recordForm'); if (!form) return;
  const t = TAB[form.querySelector('[name="category"]').value];
  $('#formTabNote').textContent = t.nameRequired ? `${t.key}: BBA ID is required` : `${t.key}: BBA ID is optional`;
}

function showNameError(form, msg) {
  const nameEl = form.querySelector('[name="bbaId"]');
  const err = form.querySelector('[data-err="bbaId"]');
  nameEl.setAttribute('aria-invalid', 'true');
  err.textContent = msg || `Enter the BBA ID. It’s required on ${form.querySelector('[name="category"]').value}.`;
  err.hidden = false;
  nameEl.focus();
}

async function saveRecord(form) {
  const vals = readForm(form);
  const tab = TAB[vals.category];
  if (tab.nameRequired && !vals.bbaId) { showNameError(form); return; }
  const id = form.dataset.id;
  const btn = $('#saveRecordBtn');
  btn.disabled = true;
  try {
    const d = id
      ? await api('PUT', `/patients/${encodeURIComponent(id)}`, { record: vals, baseUpdatedAt: Number(form.dataset.base) || null })
      : await api('POST', '/patients', { record: vals });
    upsert(d.patient);
    const moved = vals.category !== state.view && TAB[state.view];
    closeModal();
    toast(moved ? `Record saved to ${vals.category}` : 'Record saved');
    render();
  } catch (e) {
    if (e.code === 'conflict') {
      upsert(e.data.current);
      form.dataset.base = String(e.data.current.updatedAt);
      const b = $('#conflictBanner');
      b.textContent = `${e.data.current.updatedBy} changed this record while you were editing it. Your changes are still in the form. Save again to keep your version, or Cancel to see theirs.`;
      b.hidden = false;
      b.scrollIntoView({ block: 'nearest' });
      render();
    } else if (e.code === 'not_found') {
      closeModal(); toast(e.message, { type: 'error' }); syncNow();
    } else if (e.code === 'invalid' && /BBA ID/i.test(e.message)) {
      showNameError(form, e.message);
    } else fail(e);
  } finally { if (document.contains(btn)) btn.disabled = false; }
}

async function patchRecord(id, record) {
  const d = await api('PUT', `/patients/${encodeURIComponent(id)}`, { record });
  upsert(d.patient);
  return d.patient;
}

function openNotes(id) {
  const p = state.patients.find(x => x.id === id); if (!p) return;
  showModal(`
    <form id="notesForm" class="modal max-w-[560px]" data-id="${esc(p.id)}" novalidate>
      <div class="flex items-center justify-between px-6 py-4 border-b" style="border-color: var(--line)">
        <div><h2 class="text-[17px] font-bold">Notes</h2><p class="text-muted text-[12.5px]">${esc(recLabel(p))}, ${esc(p.category)}</p></div>
        <button type="button" class="icon-btn" data-close aria-label="Close"><i data-feather="x"></i></button>
      </div>
      <div class="p-6"><textarea name="notes" class="ctl" style="min-height:180px" aria-label="Notes">${esc(p.notes || '')}</textarea></div>
      <div class="px-6 pb-5 flex justify-end gap-2">
        <button type="button" class="btn btn-quiet" data-close>Cancel</button>
        <button class="btn btn-primary"><i data-feather="check"></i>Save notes</button>
      </div>
    </form>`);
  $('#notesForm textarea').focus();
}

function openMove(id) {
  const p = state.patients.find(x => x.id === id); if (!p) return;
  showModal(`
    <div class="modal max-w-[460px]" role="dialog" aria-label="Move record">
      <div class="flex items-center justify-between px-6 py-4 border-b" style="border-color: var(--line)">
        <div><h2 class="text-[17px] font-bold">Move to tab</h2><p class="text-muted text-[12.5px]">${esc(recLabel(p))}, now in ${esc(p.category)}</p></div>
        <button type="button" class="icon-btn" data-close aria-label="Close"><i data-feather="x"></i></button>
      </div>
      <div class="p-3">
        ${TABS.map(t => `
          <button class="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-left hover:bg-sunken disabled:opacity-50 disabled:cursor-not-allowed" data-move-to="${esc(t.key)}" data-id="${esc(p.id)}" ${t.key === p.category ? 'disabled' : ''}>
            <span class="swatch" style="background: var(${groupColorVar(t.group)})"></span>
            <span class="font-medium">${esc(t.key)}</span>
            <span class="ml-auto text-muted text-[12px]">${t.key === p.category ? 'Current' : GROUPS[t.group]}</span>
          </button>`).join('')}
      </div>
    </div>`);
}

async function moveRecord(id, to) {
  const p = state.patients.find(x => x.id === id); if (!p) return;
  if (TAB[to].nameRequired && !p.bbaId) { closeModal(); openRecord(id, to, true); return; }
  const from = p.category;
  try {
    await patchRecord(id, { category: to });
    closeModal();
    render();
    toast(`Moved to ${to}`, { action: { label: 'Undo', run: () => patchRecord(id, { category: from }).then(render).catch(fail) } });
  } catch (e) { fail(e); }
}

async function deleteRecord(id) {
  const p = state.patients.find(x => x.id === id); if (!p) return;
  try {
    const d = await api('DELETE', `/patients/${encodeURIComponent(id)}`);
    upsert(d.patient);
    render();
    toast(`Deleted ${recLabel(p)}`, {
      duration: 8000,
      action: { label: 'Undo', run: () => api('POST', `/patients/${encodeURIComponent(id)}/restore`).then(r => { upsert(r.patient); render(); }).catch(fail) }
    });
  } catch (e) { fail(e); }
}

async function toggleMilestone(id, k) {
  const p = state.patients.find(x => x.id === id); if (!p) return;
  try { await patchRecord(id, { [k + 'Done']: !p[k + 'Done'] }); render(); }
  catch (e) { fail(e); }
}

/* Modals */
let lastFocus = null;
function showModal(html) {
  lastFocus = document.activeElement;
  $('#modalRoot').innerHTML = `<div class="modal-wrap" data-backdrop>${html}</div>`;
  icons();
}
function closeModal() {
  $('#modalRoot').innerHTML = '';
  draft = null;
  if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
}

function askConfirm(message, opts = {}) {
  return new Promise(resolve => {
    const wrap = document.createElement('div');
    wrap.className = 'modal-wrap';
    wrap.style.zIndex = 70;
    wrap.innerHTML = `
      <form class="modal max-w-[440px] p-6" novalidate>
        <h2 class="text-[17px] font-bold">${esc(opts.title || 'Are you sure?')}</h2>
        <p class="text-muted mt-2 text-[13.5px]">${esc(message)}</p>
        ${opts.requireText ? `<label class="block mt-4"><span class="lbl">Type ${esc(opts.requireText)} to confirm</span><input class="ctl" autocomplete="off"></label><div class="err" hidden></div>` : ''}
        <div class="flex justify-end gap-2 mt-5">
          <button type="button" class="btn btn-quiet" data-no>Cancel</button>
          <button class="btn ${opts.danger ? 'btn-danger' : 'btn-primary'}">${esc(opts.confirmLabel || 'Confirm')}</button>
        </div>
      </form>`;
    const done = v => { wrap.remove(); document.removeEventListener('keydown', onKey, true); resolve(v); };
    const onKey = e => { if (e.key === 'Escape') { e.stopPropagation(); done(false); } };
    document.addEventListener('keydown', onKey, true);
    wrap.addEventListener('click', e => { if (e.target === wrap || e.target.closest('[data-no]')) done(false); });
    wrap.querySelector('form').addEventListener('submit', e => {
      e.preventDefault(); e.stopPropagation();
      if (opts.requireText) {
        const inp = wrap.querySelector('input');
        if (inp.value.trim() !== opts.requireText) { const er = wrap.querySelector('.err'); er.textContent = `Type ${opts.requireText} exactly to continue.`; er.hidden = false; inp.focus(); return; }
      }
      done(true);
    });
    document.body.appendChild(wrap);
    (wrap.querySelector('input') || wrap.querySelector('button[data-no]')).focus();
  });
}

/* ============================================================
   Admin views
   ============================================================ */
function renderSurgeons() {
  $('#surgeonList').innerHTML = state.surgeons.length ? state.surgeons.map((s, i) => {
    const n = state.patients.filter(p => p.surgeon === s).length;
    return `<li class="px-5 py-3 flex items-center gap-3" style="border-color: var(--line)">
      <span class="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style="background: var(--accent-soft); color: var(--accent)"><i data-feather="user"></i></span>
      <div class="min-w-0 flex-1"><div class="font-semibold truncate">${esc(s)}</div><div class="text-muted text-[12.5px]">${n} record${n === 1 ? '' : 's'}</div></div>
      <button class="icon-btn danger" data-del-surgeon="${i}" aria-label="Remove ${esc(s)}" title="Remove"><i data-feather="trash-2"></i></button>
    </li>`;
  }).join('') : `<li class="px-5 py-8 text-muted text-center">No surgeons on the roster. Add one above.</li>`;
}
async function saveSurgeons(list) {
  const d = await api('PUT', '/surgeons', { surgeons: list });
  state.surgeons = d.surgeons;
  render();
}

async function loadUsers() {
  if (!isAdmin()) return;
  try { const d = await api('GET', '/users'); state.users = d.users; if (state.view === 'users') { renderUsers(); icons(); } }
  catch (e) { fail(e); }
}
function renderUsers() {
  if (!state.users) return;
  $('#userList').innerHTML = state.users.map(u => {
    const me = sameEmail(u.email, state.user);
    return `<li class="px-5 py-3 flex items-center gap-3 flex-wrap" style="border-color: var(--line)">
      <span class="w-8 h-8 rounded-full flex items-center justify-center text-[12px] font-bold shrink-0" style="background: var(--accent-soft); color: var(--accent)">${esc(u.email[0].toUpperCase())}</span>
      <div class="min-w-0 flex-1 truncate">${esc(u.email)}</div>
      ${me ? '<span class="chip accent">You</span>' : ''}
      <select class="ctl" style="width:auto; min-height:32px; padding:4px 8px" data-user-role="${esc(u.email)}" aria-label="Access for ${esc(u.email)}">
        <option value="staff" ${u.role === 'staff' ? 'selected' : ''}>Staff</option>
        <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Administrator</option>
      </select>
      ${me ? '<span class="w-8"></span>' : `<button class="icon-btn danger" data-del-user="${esc(u.email)}" aria-label="Remove ${esc(u.email)}" title="Remove access"><i data-feather="user-x"></i></button>`}
    </li>`;
  }).join('');
}

async function loadAudit() {
  if (!isAdmin()) return;
  $('#auditBody').innerHTML = `<tr><td colspan="5" class="text-muted">Loading…</td></tr>`;
  try {
    const d = await api('GET', '/audit?limit=300');
    const label = {
      create: 'Added record', update: 'Edited record', move: 'Moved record', delete: 'Deleted record', restore: 'Restored record',
      'bulk-delete': 'Deleted records', import: 'Imported backup', backup: 'Downloaded backup', surgeons: 'Changed surgeon roster',
      settings: 'Changed settings', 'user-add': 'Authorized user', 'user-remove': 'Removed user', 'user-role': 'Changed access', 'users-reset': 'Re-added default users'
    };
    $('#auditBody').innerHTML = d.entries.length ? d.entries.map(a => {
      let details = '';
      if (a.action === 'move') details = `${esc(a.from)} to ${esc(a.category)}`;
      else if (a.fields?.length) details = esc(a.fields.slice(0, 6).join(', ')) + (a.fields.length > 6 ? ` and ${a.fields.length - 6} more` : '');
      else if (a.target) details = esc(a.target) + (a.role ? ` (${esc(a.role)})` : '');
      else if (a.count != null) details = `${a.count} record${a.count === 1 ? '' : 's'}${a.skipped ? `, ${a.skipped} already present` : ''}`;
      const live = a.patientId && state.patients.find(p => p.id === a.patientId);
      const rec = a.patientId ? `${esc(live ? recLabel(live) : (a.patientName || 'Record'))}<div class="text-muted text-[12px]">${esc(a.category || '')}</div>` : '';
      return `<tr style="cursor:default"><td class="whitespace-nowrap">${esc(new Date(a.at).toLocaleString())}</td><td>${esc(a.by)}</td><td>${esc(label[a.action] || a.action)}</td><td>${rec}</td><td class="text-muted">${details}</td></tr>`;
    }).join('') : `<tr><td colspan="5" class="text-muted">No activity yet.</td></tr>`;
  } catch (e) { fail(e); }
}

function renderSettings() {
  $('#compactToggle').checked = lsGet('vct_compact') === '1';
  document.querySelectorAll('#view-settings [data-admin]').forEach(el => el.hidden = !isAdmin());
  if (!isAdmin()) return;
  const f = $('#settingsForm');
  f.elements.practiceName.value = state.settings.practiceName || '';
  f.elements.defaultLocation.value = state.settings.defaultLocation || 'ATL';
  f.elements.exportPrefix.value = state.settings.exportPrefix || '';
  const demo = state.patients.some(p => p.demo);
  $('#removeDemoBtn').hidden = !demo;
}

function showErr(sel, msg) { const e = $(sel); e.textContent = msg; e.hidden = !msg; }

/* ============================================================
   Export, backup, import
   ============================================================ */
function exportColumns(type) {
  const cols = [['BBA ID', p => p.bbaId || '']];
  if (type === 'promo') {
    cols.push(['Insurance', p => p.insurance || ''], ['Location', p => p.location || ''], ['Date Promo', p => p.datePromo || ''],
      ['IV or Vanquish', p => p.ivVanquish || ''], ['US Date', p => p.usDate || '']);
  } else {
    cols.push(['Surgeon', p => p.surgeon || ''], ['Authorization Status', p => p.paStatus || ''],
      ['Approved On', p => p.paStatus === 'Approved' && p.paApprovedAt ? new Date(p.paApprovedAt).toLocaleDateString() : ''],
      ['Initial US', p => p.initialUsStatus || ''], ['Initial US Date', p => p.initialUsDate || '']);
    SIDES.forEach(s => VEINS.forEach(v => {
      const vk = `${s.k}_${v.k}`, pre = `${s.k.toUpperCase()} ${v.label}`;
      cols.push([`${pre} Procedure`, p => p[`${vk}_proc`] || 'None'],
        [`${pre} Units`, p => hasUnits(p[`${vk}_units`]) ? Number(p[`${vk}_units`]) : ''],
        [`${pre} POST AB US`, p => p[`${vk}_post`] || '']);
    }));
    if (type === 'po') {
      MILESTONES.forEach(m => cols.push([`${m.label} Date`, p => p[m.k] || ''], [`${m.label} Done`, p => p[m.k + 'Done'] ? 'Yes' : 'No']));
      cols.push(['New Veins To Treat', p => p.poNewVeinsFlag ? 'Yes' : 'No'], ['New Veins Details', p => p.poNewVeins || '']);
    }
  }
  cols.push(['Notes', p => p.notes || ''], ['Last Updated', p => p.updatedAt ? new Date(p.updatedAt).toLocaleString() : ''], ['Updated By', p => p.updatedBy || '']);
  return cols;
}

function exportXlsx() {
  const wb = XLSX.utils.book_new();
  const summary = [
    ['Vein Pre-Authorization & Treatment Tracker'],
    ['Practice', state.settings.practiceName],
    ['Exported', new Date().toLocaleString()],
    ['Exported by', state.user],
    [],
    ['Tab', 'Records'],
    ...TABS.map(t => [t.key, state.patients.filter(p => p.category === t.key).length]),
    ['Total', state.patients.length]
  ];
  const ws0 = XLSX.utils.aoa_to_sheet(summary);
  ws0['!cols'] = [{ wch: 34 }, { wch: 32 }];
  XLSX.utils.book_append_sheet(wb, ws0, 'Summary');
  TABS.forEach(t => {
    const cols = exportColumns(t.type);
    const rows = state.patients.filter(p => p.category === t.key).map(p => cols.map(([, fn]) => fn(p)));
    const ws = XLSX.utils.aoa_to_sheet([cols.map(c => c[0]), ...rows]);
    ws['!cols'] = cols.map(([h]) => ({ wch: h === 'Notes' || h === 'New Veins Details' ? 48 : Math.max(11, h.length + 2) }));
    ws['!autofilter'] = { ref: XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(rows.length, 1), c: cols.length - 1 } }) };
    XLSX.utils.book_append_sheet(wb, ws, t.key.replace(/[:\\/?*[\]]/g, '').slice(0, 31));
  });
  const prefix = (state.settings.exportPrefix || 'Vein_Tracker').replace(/[^\w\- ]+/g, '').trim() || 'Vein_Tracker';
  XLSX.writeFile(wb, `${prefix}_${localISO()}.xlsx`);
  toast('Spreadsheet exported');
}

function downloadText(filename, text, mime) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: mime }));
  a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

async function downloadBackup() {
  try {
    const d = await api('GET', '/backup');
    downloadText(`vein-tracker-backup_${localISO()}.json`, JSON.stringify(d, null, 2), 'application/json');
    toast('Backup downloaded');
  } catch (e) { fail(e); }
}

function importBackup(file) {
  const reader = new FileReader();
  reader.onload = async () => {
    let data;
    try { data = JSON.parse(reader.result); }
    catch { toast('That file is not a valid backup. Choose the .json file made with “Download backup”.', { type: 'error' }); return; }
    const list = Array.isArray(data) ? data : data?.patients;
    if (!Array.isArray(list)) { toast('That file has no patient records.', { type: 'error' }); return; }
    const real = list.filter(p => p && !p.demo).length;
    if (!await askConfirm(`Import ${real} record${real === 1 ? '' : 's'} from this file? Demo records are skipped and nothing already in the tracker is overwritten.`, { title: 'Import records', confirmLabel: 'Import records' })) return;
    try {
      const r = await api('POST', '/import', { patients: list, skipDemo: true });
      await syncNow();
      toast(`Imported ${r.added} record${r.added === 1 ? '' : 's'}${r.skipped ? `; ${r.skipped} were already here` : ''}${r.problems?.length ? `; ${r.problems.length} couldn’t be read` : ''}`, { duration: 9000 });
      render();
    } catch (e) { fail(e); }
  };
  reader.readAsText(file);
}

/* ============================================================
   Events
   ============================================================ */
function bind() {
  $('#loginForm').addEventListener('submit', e => { e.preventDefault(); requestLink($('#loginEmail').value); });
  $('#confirmForm').addEventListener('submit', e => {
    e.preventDefault();
    const v = $('#confirmEmail').value.trim();
    if (!isEmail(v)) { showErr('#confirmError', 'Enter the email the link was sent to.'); return; }
    completeLink(v);
  });
  $('#useDifferent').addEventListener('click', () => showSignin('request'));
  $('#deniedBack').addEventListener('click', () => showSignin('request'));
  $('#devLoginForm').addEventListener('submit', e => {
    e.preventDefault();
    const v = $('#devEmail').value.trim(); if (!v) return;
    devEmail = v; sessionStorage.setItem('vct_dev_email', v);
    enterApp();
  });
  $('#logoutBtn').addEventListener('click', () => signOut());
  $('#menuBtn').addEventListener('click', openSidebar);
  $('#scrim').addEventListener('click', closeSidebar);
  $('#exportBtn').addEventListener('click', exportXlsx);
  $('#addBtn').addEventListener('click', () => openRecord(null));
  $('#search').addEventListener('input', e => { state.search = e.target.value; renderList(); icons(); });

  $('#bellBtn').addEventListener('click', e => {
    e.stopPropagation();
    const panel = $('#bellPanel');
    panel.hidden = !panel.hidden;
    $('#bellBtn').setAttribute('aria-expanded', String(!panel.hidden));
    renderBell();
  });
  document.addEventListener('click', async e => {
    const t = e.target;
    if (t.closest('[data-mark-all]')) { markAllRead(); return; }
    const ob = t.closest('[data-open-bell]');
    if (ob) { e.stopPropagation(); $('#bellPanel').hidden = false; $('#bellBtn').setAttribute('aria-expanded', 'true'); renderBell(); $('#main').scrollTop = 0; return; }
    const nb = t.closest('[data-notif]');
    if (nb) {
      const g = unreadGroups().find(x => x.key === nb.dataset.notif);
      if (!g) return;
      if (state.patients.some(p => p.id === g.patientId)) openRecord(g.patientId);
      else { closeBell(); markRead(g.events); toast(`${g.bbaId || 'That record'} was deleted by ${g.latest.by}.`); }
      return;
    }
    if (!t.closest('#bellPanel') && !$('#bellPanel').hidden) closeBell();
    const nav = t.closest('[data-nav]'); if (nav && !nav.disabled) { navigate(nav.dataset.nav); return; }
    const ms = t.closest('[data-ms]'); if (ms) { toggleMilestone(ms.dataset.id, ms.dataset.ms); return; }
    const ed = t.closest('[data-edit]'); if (ed) { openRecord(ed.dataset.edit); return; }
    const del = t.closest('[data-del]'); if (del) { deleteRecord(del.dataset.del); return; }
    const mv = t.closest('[data-move]'); if (mv) { openMove(mv.dataset.move); return; }
    const nt = t.closest('[data-notes]'); if (nt) { openNotes(nt.dataset.notes); return; }
    const mvTo = t.closest('[data-move-to]'); if (mvTo) { moveRecord(mvTo.dataset.id, mvTo.dataset.moveTo); return; }
    if (t.closest('[data-add]')) { openRecord(null); return; }
    if (t.closest('[data-clear-search]')) { state.search = ''; $('#search').value = ''; renderList(); icons(); return; }
    if (t.closest('[data-close]') || t.matches('[data-backdrop]')) { closeModal(); return; }
    if (t.closest('[data-fill-ms]')) {
      const base = $('#procDateHelper').value;
      if (!base) { $('#procDateHelper').focus(); toast('Pick the procedure date first.', { type: 'error' }); return; }
      const d0 = new Date(base + 'T00:00:00');
      const f = $('#recordForm');
      const addMonths = n => { const last = new Date(d0.getFullYear(), d0.getMonth() + n + 1, 0).getDate(); return localISO(new Date(d0.getFullYear(), d0.getMonth() + n, Math.min(d0.getDate(), last))); };
      f.querySelector('[name="po30Day"]').value = addDays(30, d0);
      f.querySelector('[name="po3Month"]').value = addMonths(3);
      f.querySelector('[name="po6Month"]').value = addMonths(6);
      f.querySelector('[name="po12Month"]').value = addMonths(12);
      return;
    }
    const row = t.closest('tr[data-row]');
    if (row && !t.closest('button, a, input, select')) { openRecord(row.dataset.row); return; }
    const ds = t.closest('[data-del-surgeon]');
    if (ds) {
      const s = state.surgeons[+ds.dataset.delSurgeon];
      try {
        await saveSurgeons(state.surgeons.filter((_, i) => i !== +ds.dataset.delSurgeon));
        toast(`Removed ${s}`, { action: { label: 'Undo', run: () => saveSurgeons([...state.surgeons, s]).catch(fail) } });
      } catch (err) { fail(err); }
      return;
    }
    const du = t.closest('[data-del-user]');
    if (du) {
      const email = du.dataset.delUser;
      try {
        const r = await api('DELETE', `/users/${encodeURIComponent(email)}`);
        await loadUsers();
        toast(`${email} can no longer sign in`, { action: { label: 'Undo', run: () => api('POST', '/users/restore', { email, role: r.user.role }).then(loadUsers).catch(fail) } });
      } catch (err) { fail(err); }
    }
  });

  document.addEventListener('change', async e => {
    const t = e.target;
    if (t.matches('select.proc')) t.dataset.proc = t.value;
    if (t.form && t.form.id === 'recordForm' && t.name === 'category') {
      draft = { ...draft, ...readForm(t.form) };
      const nt = TAB[draft.category];
      if (nt.surgeonMatch && !draft.surgeon) draft.surgeon = state.surgeons.find(s => nt.surgeonMatch.test(s)) || '';
      $('#formBody').innerHTML = formBody(draft);
      updateFormNote();
      icons();
    }
    if (t.matches('[data-user-role]')) {
      try { await api('PATCH', `/users/${encodeURIComponent(t.dataset.userRole)}`, { role: t.value }); toast('Access updated'); }
      catch (err) { fail(err); }
      loadUsers();
    }
    if (t.id === 'compactToggle') { lsSet('vct_compact', t.checked ? '1' : '0'); render(); }
  });
  document.addEventListener('input', e => {
    if (e.target.name === 'bbaId' && e.target.form?.id === 'recordForm') {
      e.target.removeAttribute('aria-invalid');
      const err = e.target.form.querySelector('[data-err="bbaId"]'); if (err) err.hidden = true;
    }
  });
  document.addEventListener('submit', async e => {
    if (e.target.id === 'recordForm') { e.preventDefault(); saveRecord(e.target); }
    if (e.target.id === 'notesForm') {
      e.preventDefault();
      try { await patchRecord(e.target.dataset.id, { notes: e.target.elements.notes.value.trim() }); closeModal(); toast('Notes saved'); render(); }
      catch (err) { fail(err); }
    }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { if (!$('#bellPanel').hidden) closeBell(); else if ($('#modalRoot').innerHTML) closeModal(); else closeSidebar(); }
  });

  $('#surgeonForm').addEventListener('submit', async e => {
    e.preventDefault();
    const v = $('#surgeonInput').value.trim();
    if (!v) return showErr('#surgeonErr', 'Enter the surgeon’s name.');
    if (state.surgeons.some(s => s.toLowerCase() === v.toLowerCase())) return showErr('#surgeonErr', `${v} is already on the roster.`);
    showErr('#surgeonErr', '');
    try { await saveSurgeons([...state.surgeons, v]); $('#surgeonInput').value = ''; toast(`Added ${v}`); } catch (err) { fail(err); }
  });
  $('#resetSurgeons').addEventListener('click', async () => {
    if (!await askConfirm('Replace the surgeon roster with the defaults?', { title: 'Restore default roster', confirmLabel: 'Restore roster' })) return;
    try { await saveSurgeons(['Dr. Charles Procter', 'Dr. V. Danthuluri']); toast('Surgeon roster restored'); } catch (err) { fail(err); }
  });
  $('#userForm').addEventListener('submit', async e => {
    e.preventDefault();
    const v = $('#userInput').value.trim();
    if (!isEmail(v)) return showErr('#userErr', 'Enter a full email address, like name@beltlinehealth.com.');
    showErr('#userErr', '');
    try {
      await api('POST', '/users', { email: v, role: $('#userRoleInput').value });
      $('#userInput').value = '';
      await loadUsers();
      toast(`${v} can now sign in`);
    } catch (err) { if (err.code === 'exists' || err.code === 'invalid') showErr('#userErr', err.message); else fail(err); }
  });
  $('#resetUsers').addEventListener('click', async () => {
    if (!await askConfirm('Re-add any of the original 10 users who were removed? Nobody is removed and existing access levels stay the same.', { title: 'Re-add original users', confirmLabel: 'Re-add users' })) return;
    try { const r = await api('POST', '/users/reset'); await loadUsers(); toast(r.added ? `Re-added ${r.added} user${r.added === 1 ? '' : 's'}` : 'All 10 original users already have access'); }
    catch (err) { fail(err); }
  });
  $('#settingsForm').addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target.elements;
    try {
      const d = await api('PUT', '/settings', { settings: { practiceName: f.practiceName.value, defaultLocation: f.defaultLocation.value, exportPrefix: f.exportPrefix.value } });
      state.settings = d.settings; render(); toast('Settings saved');
    } catch (err) { fail(err); }
  });
  $('#backupBtn').addEventListener('click', downloadBackup);
  $('#restoreInput').addEventListener('change', e => { if (e.target.files[0]) importBackup(e.target.files[0]); e.target.value = ''; });
  $('#removeDemoBtn').addEventListener('click', async () => {
    const ids = state.patients.filter(p => p.demo).map(p => p.id);
    if (!ids.length || !await askConfirm(`Remove ${ids.length} demo record${ids.length > 1 ? 's' : ''}?`, { title: 'Remove demo records', confirmLabel: 'Remove demo records' })) return;
    try { await api('POST', '/patients/bulk-delete', { ids }); await syncNow(); render(); toast(`Removed ${ids.length} demo records`); } catch (err) { fail(err); }
  });
  $('#wipeBtn').addEventListener('click', async () => {
    const ids = state.patients.map(p => p.id);
    if (!await askConfirm(`This deletes all ${ids.length} patient records for everyone.`, { title: 'Delete all records', confirmLabel: 'Delete all records', danger: true, requireText: 'DELETE' })) return;
    try { await api('POST', '/patients/bulk-delete', { ids }); await syncNow(); render(); toast('All patient records deleted'); } catch (err) { fail(err); }
  });

  document.addEventListener('visibilitychange', () => { if (!document.hidden) syncNow(); });
  window.addEventListener('focus', syncNow);
  window.addEventListener('online', syncNow);

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    if (state.chart) { state.chart.destroy(); state.chart = null; }
    if (state.user && viewKind() === 'dashboard') renderChart();
  });
}

/* ============================================================
   Boot
   ============================================================ */
function brandMarks() {
  const svg = `<svg width="30" height="30" viewBox="0 0 30 30" aria-hidden="true"><rect width="30" height="30" rx="7" fill="#2D4EA2"/><path d="M15 5 C14 10 16 13 15 17 S13 22 14 25" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M15 17 C18 18 20 21 21 25" stroke="#BFD0FF" stroke-width="1.9" fill="none" stroke-linecap="round"/><path d="M15.2 10 C12.5 11 10.5 12.5 9 14.5" stroke="#BFD0FF" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg>`;
  document.querySelectorAll('.brand-mark').forEach(el => el.innerHTML = svg);
}

async function boot() {
  brandMarks();
  bind();
  try { config = await fetch('/api/config').then(r => { if (!r.ok) throw new Error(); return r.json(); }); }
  catch { $('#loading').textContent = 'Can’t reach the tracker server. Check your connection, then reload the page.'; return; }
  document.querySelectorAll('[data-practice]').forEach(el => el.textContent = config.practiceName);

  if (config.devAuth) {
    devEmail = sessionStorage.getItem('vct_dev_email');
    if (devEmail) enterApp(); else showSignin('request');
    return;
  }

  const fbApp = initializeApp(config.firebase);
  auth = initializeAuth(fbApp, { persistence: browserLocalPersistence });

  let completing = false;
  if (isSignInWithEmailLink(auth, location.href)) {
    completing = true;
    const email = lsGet(EMAIL_KEY);
    if (email) completeLink(email);
    else showSignin('confirm');
  }

  onAuthStateChanged(auth, user => {
    if (user) {
      const last = Number(lsGet(ACTIVE_KEY)) || 0;
      if (Date.now() - last > (config.idleMinutes || 30) * 60000) {
        signOut(`You were signed out after ${config.idleMinutes || 30} minutes without activity.`);
        return;
      }
      enterApp();
    } else if (!completing) {
      if (entered) stopSession();
      showSignin('request');
    }
    completing = false;
  });
}

boot();
