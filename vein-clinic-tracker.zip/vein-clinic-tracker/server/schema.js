// Server-side source of truth for what a patient record may contain.
// Field names match the original browser-only tracker so old backups import cleanly.

export const TAB_KEYS = [
  'Promo',
  'Procter Pay Attention',
  'Dr. Procter',
  'Dr. Danthuluri',
  'PO Vein FU',
  'PA DENIED',
  'Not Interested Now or excluded'
];
// BBA ID identifies a record. It is optional on these two tabs and required on the rest.
export const ID_OPTIONAL_TABS = new Set(['Promo', 'Procter Pay Attention']);

const SIDES = ['r', 'l'];
const VEINS = ['gsv', 'ssv', 'pasv', 'aasv', 'btk'];
export const VEIN_KEYS = SIDES.flatMap(s => VEINS.map(v => `${s}_${v}`));
export const MILESTONE_KEYS = ['po30Day', 'po3Month', 'po6Month', 'po12Month'];

const STR = { type: 'str', max: 200 };
const TEXT = { type: 'str', max: 10000 };
const DATE = { type: 'date' };
const BOOL = { type: 'bool' };

export const FIELDS = {
  category: { type: 'enum', values: TAB_KEYS },
  name: STR,
  bbaId: STR,
  notes: TEXT,
  surgeon: STR,
  insurance: STR,
  location: STR,
  datePromo: DATE,
  ivVanquish: STR,
  usDate: DATE,
  poNewVeinsFlag: BOOL,
  poNewVeins: TEXT,
  paStatus: STR,          // Authorization status: '', Submitted, Pending, Approved, Denied
  initialUsStatus: STR,   // Initial U/S documentation: '', Requested, Received, Reviewed, Not needed
  initialUsDate: DATE,
  surgeryDate: DATE,       // older single-surgery field; new entries go in treatments
  treatments: { type: 'treatments' }  // [{ id, date, postUsDate, veins: { r_gsv: 'RFA', ... } }]
};
// paApprovedAt / paApprovedBy are set by the server only, never accepted from the browser.
VEIN_KEYS.forEach(vk => {
  FIELDS[`${vk}_proc`] = STR; // legacy values are kept, so not a strict enum
  FIELDS[`${vk}_units`] = { type: 'num' };
  FIELDS[`${vk}_post`] = STR;
  FIELDS[`${vk}_tx`] = STR;   // treatment performed at surgery (units and POST AB US are shared with the plan)
});
MILESTONE_KEYS.forEach(k => {
  FIELDS[k] = DATE;
  FIELDS[`${k}Done`] = BOOL;
});

// Returns { value } or { error }. Unknown fields are dropped.
export function sanitizePatient(input, { partial = false } = {}) {
  if (!input || typeof input !== 'object') return { error: 'Record must be an object.' };
  const out = {};
  for (const [key, spec] of Object.entries(FIELDS)) {
    if (!(key in input)) continue;
    const v = input[key];
    if (v === null || v === undefined) { out[key] = spec.type === 'bool' ? false : ''; continue; }
    switch (spec.type) {
      case 'str':
        out[key] = String(v).slice(0, spec.max).trim();
        break;
      case 'enum':
        if (!spec.values.includes(v)) return { error: `Unknown value for ${key}.` };
        out[key] = v;
        break;
      case 'date':
        if (v === '') { out[key] = ''; break; }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(v))) return { error: `${key} must be a date (YYYY-MM-DD).` };
        out[key] = String(v);
        break;
      case 'bool':
        out[key] = v === true || v === 'true';
        break;
      case 'treatments': {
        if (!Array.isArray(v)) return { error: 'Treatments must be a list.' };
        if (v.length > 50) return { error: 'A record can have at most 50 treatments.' };
        const isDate = d => d === '' || /^\d{4}-\d{2}-\d{2}$/.test(String(d));
        const list = [];
        for (const t of v) {
          if (!t || typeof t !== 'object') return { error: 'Invalid treatment entry.' };
          const date = t.date ?? '', postUsDate = t.postUsDate ?? '';
          if (!isDate(date) || !isDate(postUsDate)) return { error: 'Treatment dates must be dates (YYYY-MM-DD).' };
          const veins = {};
          for (const vk of VEIN_KEYS) if (t.veins && t.veins[vk]) veins[vk] = String(t.veins[vk]).slice(0, 40);
          list.push({ id: String(t.id || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40) || 't' + list.length, date: String(date), postUsDate: String(postUsDate), veins });
        }
        out[key] = list;
        break;
      }
      case 'num': {
        if (v === '') { out[key] = ''; break; }
        const n = typeof v === 'number' ? v : parseFloat(v);
        out[key] = Number.isFinite(n) && n >= 0 && n < 100000 ? n : '';
        break;
      }
    }
  }
  if (!partial) {
    if (!out.category) return { error: 'Choose a tab for this record.' };
    if (!ID_OPTIONAL_TABS.has(out.category) && !out.bbaId) {
      return { error: `BBA ID is required on ${out.category}.` };
    }
  }
  return { value: out };
}

export function sanitizeEmail(e) {
  const s = String(e || '').trim();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s) && s.length <= 254 ? s : null;
}

export const DEFAULT_USERS = [
  'Dianaw@beltlinehealth.com',
  'alnisah@beltlinehealth.com',
  'taquoyap@beltlinehealth.com',
  'cproctermd@beltlinehealth.com',
  'vdanmd@beltlinehealth.com',
  'virtualstaff.miranda.09042024@gmail.com',
  'youroutsourcedexpert@gmail.com',
  'virtualstaff.benedicto.05202024@gmail.com',
  'Corbin@smb-sc.com',
  'virtualstaff.wenceslao.011325@gmail.com'
];
export const DEFAULT_SURGEONS = ['Dr. Charles Procter', 'Dr. V. Danthuluri'];
export const DEFAULT_SETTINGS = { practiceName: 'Beltline Health', defaultLocation: 'ATL', exportPrefix: 'Vein_PreAuth_Tracker' };
