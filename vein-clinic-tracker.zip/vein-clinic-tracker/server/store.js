// Storage layer. Production uses Firestore (covered by the Google Cloud BAA).
// STORE=memory gives an in-process store for local development and tests only.
import crypto from 'node:crypto';

const newId = () => 'p_' + crypto.randomBytes(9).toString('base64url');
const lc = s => String(s).toLowerCase();

/* ---------------- Firestore ---------------- */
async function firestoreStore() {
  const { Firestore } = await import('@google-cloud/firestore');
  const db = new Firestore({
    databaseId: process.env.FIRESTORE_DATABASE || '(default)',
    ignoreUndefinedProperties: true
  });
  const P = db.collection('patients');
  const U = db.collection('users');
  const C = db.collection('config');
  const A = db.collection('audit');
  const E = db.collection('events');      // shared notifications (added / updated / approved ...)
  const N = db.collection('notifState');  // per-user read markers, keyed by lowercase email
  const docs = snap => snap.docs.map(d => ({ id: d.id, ...d.data() }));

  return {
    kind: 'firestore',
    async listPatients() { return docs(await P.where('deleted', '==', false).get()); },
    async changedSince(since) { return docs(await P.where('updatedAt', '>', since).get()); },
    async getPatient(id) { const s = await P.doc(id).get(); return s.exists ? { id, ...s.data() } : null; },
    async createPatient(fields, meta) {
      const id = newId();
      const rec = { ...fields, deleted: false, demo: false, createdAt: meta.now, updatedAt: meta.now, updatedBy: meta.by };
      await P.doc(id).create(rec);
      return { id, ...rec };
    },
    async updatePatient(id, fields, meta, baseUpdatedAt) {
      return db.runTransaction(async tx => {
        const ref = P.doc(id);
        const snap = await tx.get(ref);
        if (!snap.exists || snap.data().deleted) return { notFound: true };
        const cur = { id, ...snap.data() };
        if (baseUpdatedAt != null && cur.updatedAt !== baseUpdatedAt) return { conflict: true, current: cur };
        const updatedAt = Math.max(meta.now, (cur.updatedAt || 0) + 1);
        const next = { ...fields, demo: false, updatedAt, updatedBy: meta.by };
        tx.update(ref, next);
        return { value: { ...cur, ...next }, before: cur };
      });
    },
    async setDeleted(id, deleted, meta) {
      return db.runTransaction(async tx => {
        const ref = P.doc(id);
        const snap = await tx.get(ref);
        if (!snap.exists) return null;
        const cur = snap.data();
        const updatedAt = Math.max(meta.now, (cur.updatedAt || 0) + 1);
        tx.update(ref, { deleted, updatedAt, updatedBy: meta.by });
        return { id, ...cur, deleted, updatedAt, updatedBy: meta.by };
      });
    },
    async importPatients(records) {
      // records already sanitized and stamped; a record that already exists is never overwritten
      let added = 0, skipped = 0;
      for (let i = 0; i < records.length; i += 200) {
        const chunk = records.slice(i, i + 200);
        const snaps = await db.getAll(...chunk.map(r => P.doc(r.id)));
        const batch = db.batch();
        snaps.forEach((s, j) => {
          const r = chunk[j];
          if (!s.exists) { batch.set(P.doc(r.id), r); added++; } else skipped++;
        });
        if (added) await batch.commit();
      }
      return { added, skipped };
    },
    async getConfig(name) { const s = await C.doc(name).get(); return s.exists ? s.data() : null; },
    async setConfig(name, value) { await C.doc(name).set(value); return value; },
    async listUsers() { return docs(await U.get()).map(({ id, ...u }) => u); },
    async getUser(email) { const s = await U.doc(lc(email)).get(); return s.exists ? s.data() : null; },
    async putUser(user) { await U.doc(lc(user.email)).set(user); return user; },
    async deleteUser(email) { await U.doc(lc(email)).delete(); },
    async userCount() { return (await U.count().get()).data().count; },
    async addAudit(entry) { await A.add(entry); },
    async listAudit(limit) { return docs(await A.orderBy('at', 'desc').limit(limit).get()); },
    async addEvent(e) { const ref = await E.add(e); return { id: ref.id, ...e }; },
    async eventsSince(since, limit) { return docs(await E.where('at', '>', since).orderBy('at', 'desc').limit(limit).get()); },
    async getNotifState(email) { const s = await N.doc(lc(email)).get(); return s.exists ? s.data() : { readAllAt: 0, read: {} }; },
    async setNotifState(email, st) { await N.doc(lc(email)).set(st); return st; }
  };
}

/* ---------------- Memory (dev/test only) ---------------- */
function memoryStore() {
  const P = new Map(), U = new Map(), C = new Map(), A = [], E = [], N = new Map();
  let eventSeq = 0;
  const clone = o => o && JSON.parse(JSON.stringify(o));
  return {
    kind: 'memory',
    async listPatients() { return [...P.values()].filter(p => !p.deleted).map(clone); },
    async changedSince(since) { return [...P.values()].filter(p => p.updatedAt > since).map(clone); },
    async getPatient(id) { return clone(P.get(id)) || null; },
    async createPatient(fields, meta) {
      const id = newId();
      const rec = { id, ...fields, deleted: false, demo: false, createdAt: meta.now, updatedAt: meta.now, updatedBy: meta.by };
      P.set(id, rec); return clone(rec);
    },
    async updatePatient(id, fields, meta, baseUpdatedAt) {
      const cur = P.get(id);
      if (!cur || cur.deleted) return { notFound: true };
      if (baseUpdatedAt != null && cur.updatedAt !== baseUpdatedAt) return { conflict: true, current: clone(cur) };
      const before = clone(cur);
      Object.assign(cur, fields, { demo: false, updatedAt: Math.max(meta.now, cur.updatedAt + 1), updatedBy: meta.by });
      return { value: clone(cur), before };
    },
    async setDeleted(id, deleted, meta) {
      const cur = P.get(id); if (!cur) return null;
      Object.assign(cur, { deleted, updatedAt: Math.max(meta.now, cur.updatedAt + 1), updatedBy: meta.by });
      return clone(cur);
    },
    async importPatients(records) {
      let added = 0, skipped = 0;
      records.forEach(r => { if (!P.has(r.id)) { P.set(r.id, clone(r)); added++; } else skipped++; });
      return { added, skipped };
    },
    async getConfig(name) { return clone(C.get(name)) || null; },
    async setConfig(name, value) { C.set(name, clone(value)); return value; },
    async listUsers() { return [...U.values()].map(clone); },
    async getUser(email) { return clone(U.get(lc(email))) || null; },
    async putUser(user) { U.set(lc(user.email), clone(user)); return user; },
    async deleteUser(email) { U.delete(lc(email)); },
    async userCount() { return U.size; },
    async addAudit(entry) { A.unshift(clone(entry)); },
    async listAudit(limit) { return A.slice(0, limit).map(clone); },
    async addEvent(e) { const ev = { id: 'e' + (++eventSeq), ...clone(e) }; E.unshift(ev); return clone(ev); },
    async eventsSince(since, limit) { return E.filter(e => e.at > since).slice(0, limit).map(clone); },
    async getNotifState(email) { return clone(N.get(lc(email))) || { readAllAt: 0, read: {} }; },
    async setNotifState(email, st) { N.set(lc(email), clone(st)); return st; }
  };
}

export async function createStore() {
  if (process.env.STORE === 'memory') {
    if (process.env.NODE_ENV === 'production') throw new Error('STORE=memory is not allowed in production.');
    const m = memoryStore();
    // Dev/test only: start with existing records, e.g. to rehearse a cleanup against a copy of real data
    if (process.env.DEV_SEED_FILE) {
      const { readFileSync } = await import('node:fs');
      for (const r of JSON.parse(readFileSync(process.env.DEV_SEED_FILE, 'utf8'))) await m.importPatients([{ deleted: false, ...r }]);
    }
    return m;
  }
  return firestoreStore();
}
