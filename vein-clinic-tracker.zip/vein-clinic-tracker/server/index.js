import express from 'express';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { createStore } from './store.js';
import {
  sanitizePatient, sanitizeEmail, TAB_KEYS, FIELDS,
  DEFAULT_USERS, DEFAULT_SURGEONS, DEFAULT_SETTINGS
} from './schema.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROD = process.env.NODE_ENV === 'production';
const PORT = process.env.PORT || 8080;
const PROJECT_ID = process.env.PROJECT_ID;
const DEV_AUTH = process.env.AUTH_MODE === 'dev';
const IDLE_MINUTES = Number(process.env.IDLE_MINUTES || 30);
const ADMIN_EMAILS = (process.env.ADMIN_EMAILS || '').split(',').map(s => s.trim()).filter(Boolean);

if (DEV_AUTH && PROD) throw new Error('AUTH_MODE=dev is not allowed in production.');
if (!DEV_AUTH && !PROJECT_ID) throw new Error('Set PROJECT_ID to your Google Cloud project id.');
if (!DEV_AUTH && (!process.env.IDP_API_KEY || !process.env.IDP_AUTH_DOMAIN)) {
  throw new Error('Set IDP_API_KEY and IDP_AUTH_DOMAIN from Identity Platform > Application setup details.');
}

const store = await createStore();
const now = () => Date.now();
const lc = s => String(s).toLowerCase();

/* ---------- First-run setup ---------- */
async function bootstrap() {
  if ((await store.userCount()) === 0) {
    for (const email of DEFAULT_USERS) {
      await store.putUser({ email, role: 'staff', addedBy: 'setup', addedAt: now() });
    }
  }
  // ADMIN_EMAILS always have admin access (break-glass for lockouts)
  for (const email of ADMIN_EMAILS) {
    const u = await store.getUser(email);
    if (!u || u.role !== 'admin') {
      await store.putUser({ email: u?.email || email, role: 'admin', addedBy: 'ADMIN_EMAILS', addedAt: u?.addedAt || now() });
    }
  }
  if (!(await store.getConfig('surgeons'))) await store.setConfig('surgeons', { list: DEFAULT_SURGEONS, updatedAt: now() });
  if (!(await store.getConfig('settings'))) await store.setConfig('settings', { ...DEFAULT_SETTINGS, updatedAt: now() });
}
await bootstrap();

// Remove sample records (never real patients): flagged demo, or named "Demo Patient X" by early versions.
// Soft-deleted, so they also disappear from every open tracker on its next sync.
const isDemo = p => p.demo === true || /^Demo Patient [A-Z]$/.test(String(p.name || '').trim());
async function purgeDemo() {
  const demo = (await store.listPatients()).filter(isDemo);
  for (const p of demo) await store.setDeleted(p.id, true, { now: Date.now(), by: 'system: demo cleanup' });
  if (demo.length) console.log(`Removed ${demo.length} demo record(s).`);
}
await purgeDemo();

/* ---------- Auth ---------- */
const JWKS = createRemoteJWKSet(new URL('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com'));

async function emailFromToken(token) {
  if (DEV_AUTH && token.startsWith('dev:')) return token.slice(4);
  const { payload } = await jwtVerify(token, JWKS, {
    issuer: `https://securetoken.google.com/${PROJECT_ID}`,
    audience: PROJECT_ID
  });
  if (!payload.email || payload.email_verified !== true) throw new Error('unverified');
  return payload.email;
}

async function requireUser(req, res, next) {
  try {
    const h = req.get('authorization') || '';
    if (!h.startsWith('Bearer ')) return res.status(401).json({ error: 'signed_out', message: 'Sign in to continue.' });
    const email = await emailFromToken(h.slice(7));
    const user = await store.getUser(email);
    if (!user) return res.status(403).json({ error: 'not_authorized', message: `${email} is not on the authorized list. Ask an administrator to add it.` });
    req.user = { email: user.email, role: user.role };
    next();
  } catch (e) {
    res.status(401).json({ error: 'signed_out', message: 'Your sign-in expired. Sign in again.' });
  }
}
const requireAdmin = (req, res, next) =>
  req.user.role === 'admin' ? next() : res.status(403).json({ error: 'admin_only', message: 'Only administrators can do this.' });

const audit = (req, action, extra = {}) =>
  store.addAudit({ at: now(), by: req.user.email, action, ...extra }).catch(e => console.error('audit failed', e));

const publicPatient = p => { const { sourceUpdatedAt, ...rest } = p; return rest; };

/* ---------- Shared notifications ---------- */
const EVENT_WINDOW_MS = 30 * 864e5;   // notifications older than 30 days drop off
const EVENT_LIMIT = 400;
const publicEvent = e => ({ id: e.id, at: e.at, by: e.by, type: e.type, patientId: e.patientId, bbaId: e.bbaId || '', category: e.category, from: e.from, fields: e.fields || [] });
function emitEvent(req, type, patient, extra = {}) {
  return store.addEvent({
    at: now(), by: req.user.email, type,
    patientId: patient.id, bbaId: patient.bbaId || '', category: patient.category,
    ...extra,
    expireAt: new Date(now() + 90 * 864e5)  // optional Firestore TTL cleanup
  }).catch(e => { console.error('event failed', e); return null; });
}
// Approval stamps are set here, never by the browser
function stampApproval(value, before, email) {
  if (value.paStatus === 'Approved') {
    if (before?.paStatus !== 'Approved') return { ...value, paApprovedAt: now(), paApprovedBy: email };
    return value; // already approved: keep the original stamp
  }
  return { ...value, paApprovedAt: '', paApprovedBy: '' };
}
// New notes get the server's time and the signed-in user; existing notes keep their original author and time
function stampNotes(value, before, email) {
  if (!Array.isArray(value.noteLog)) return value;
  const old = new Map((Array.isArray(before?.noteLog) ? before.noteLog : []).map(n => [n.id, n]));
  const t = now();
  return { ...value, noteLog: value.noteLog.map(n => old.has(n.id) ? { ...n, at: old.get(n.id).at, by: old.get(n.id).by } : { ...n, at: t, by: email }) };
}
async function notifState(email) {
  const st = await store.getNotifState(email);
  return { readAllAt: st.readAllAt || 0, read: st.read || {} };
}
// Empty-ish values ('', None, false, []) count as the same, so saving a form doesn't report untouched fields
const norm = v => (v === undefined || v === null || v === '' || v === 'None' || v === false || (Array.isArray(v) && !v.length)) ? '' : JSON.stringify(v);
const changedFields = (before, after) =>
  Object.keys(FIELDS).filter(k => k in after && norm(before?.[k]) !== norm(after[k]));

/* ---------- App ---------- */
const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'style-src': ["'self'", "'unsafe-inline'"],
      'img-src': ["'self'", 'data:'],
      'font-src': ["'self'"],
      'connect-src': ["'self'", 'https://identitytoolkit.googleapis.com', 'https://securetoken.googleapis.com'],
      'frame-ancestors': ["'none'"],
      'form-action': ["'self'"],
      'object-src': ["'none'"],
      'base-uri': ["'self'"],
      'upgrade-insecure-requests': PROD ? [] : null
    }
  },
  crossOriginEmbedderPolicy: false,
  referrerPolicy: { policy: 'no-referrer' }
}));

app.use(compression());

app.get('/healthz', (req, res) => res.json({ ok: true }));

const api = express.Router();
api.use(rateLimit({ windowMs: 5 * 60 * 1000, limit: 1500, standardHeaders: 'draft-7', legacyHeaders: false }));
api.use(express.json({ limit: '8mb' }));
api.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

// Public: what the sign-in screen needs. None of this is secret.
api.get('/config', async (req, res) => {
  const settings = await store.getConfig('settings');
  res.json({
    devAuth: DEV_AUTH,
    idleMinutes: IDLE_MINUTES,
    practiceName: settings?.practiceName || DEFAULT_SETTINGS.practiceName,
    firebase: DEV_AUTH ? null : { apiKey: process.env.IDP_API_KEY, authDomain: process.env.IDP_AUTH_DOMAIN, projectId: PROJECT_ID }
  });
});

api.use(requireUser);

const cfg = async () => {
  const [s, st] = await Promise.all([store.getConfig('surgeons'), store.getConfig('settings')]);
  const { updatedAt: _a, ...settings } = st || DEFAULT_SETTINGS;
  return { surgeons: s?.list || [], settings };
};

api.get('/bootstrap', async (req, res) => {
  const serverTime = now();
  const [patients, c, events, notif] = await Promise.all([
    store.listPatients(), cfg(), store.eventsSince(serverTime - EVENT_WINDOW_MS, EVENT_LIMIT), notifState(req.user.email)
  ]);
  res.json({ me: req.user, patients: patients.map(publicPatient), ...c, events: events.map(publicEvent), notif, serverTime });
});

api.get('/sync', async (req, res) => {
  const since = Number(req.query.since) || 0;
  const serverTime = now();
  const [patients, c, events, notif] = await Promise.all([
    store.changedSince(since - 5000), cfg(), store.eventsSince(Math.max(since - 5000, serverTime - EVENT_WINDOW_MS), EVENT_LIMIT), notifState(req.user.email)
  ]);
  res.json({ patients: patients.map(publicPatient), ...c, events: events.map(publicEvent), notif, serverTime });
});

/* Patients */
api.post('/patients', async (req, res) => {
  const { value, error } = sanitizePatient(req.body?.record);
  if (error) return res.status(400).json({ error: 'invalid', message: error });
  const rec = await store.createPatient(stampNotes(stampApproval(value, null, req.user.email), null, req.user.email), { now: now(), by: req.user.email });
  audit(req, 'create', { patientId: rec.id, patientName: rec.name || '', category: rec.category });
  await emitEvent(req, rec.paStatus === 'Approved' ? 'approved' : 'added', rec);
  res.status(201).json({ patient: publicPatient(rec) });
});

api.put('/patients/:id', async (req, res) => {
  const existing = await store.getPatient(req.params.id);
  if (!existing || existing.deleted) return res.status(404).json({ error: 'not_found', message: 'This record was deleted by someone else.' });
  const merged = { ...existing, ...(req.body?.record || {}) };
  const { value, error } = sanitizePatient(merged);
  if (error) return res.status(400).json({ error: 'invalid', message: error });
  const base = req.body?.baseUpdatedAt;
  const stamped = stampNotes(stampApproval(value, existing, req.user.email), existing, req.user.email);
  const r = await store.updatePatient(req.params.id, stamped, { now: now(), by: req.user.email }, typeof base === 'number' ? base : null);
  if (r.notFound) return res.status(404).json({ error: 'not_found', message: 'This record was deleted by someone else.' });
  if (r.conflict) return res.status(409).json({ error: 'conflict', current: publicPatient(r.current), message: `${r.current.updatedBy} changed this record while you were editing it.` });
  const fields = changedFields(r.before, value);
  const action = r.before.category !== value.category ? 'move' : 'update';
  audit(req, action, { patientId: r.value.id, patientName: r.value.name || '', category: r.value.category, from: action === 'move' ? r.before.category : undefined, fields });
  if (fields.length) {
    const approvedNow = r.value.paStatus === 'Approved' && r.before.paStatus !== 'Approved';
    const type = approvedNow ? 'approved' : action === 'move' ? 'moved' : 'updated';
    await emitEvent(req, type, r.value, { fields, from: action === 'move' ? r.before.category : undefined });
  }
  res.json({ patient: publicPatient(r.value) });
});

api.delete('/patients/:id', async (req, res) => {
  const p = await store.setDeleted(req.params.id, true, { now: now(), by: req.user.email });
  if (!p) return res.status(404).json({ error: 'not_found', message: 'Record not found.' });
  audit(req, 'delete', { patientId: p.id, patientName: p.name || '', category: p.category });
  await emitEvent(req, 'deleted', p);
  res.json({ patient: publicPatient(p) });
});

api.post('/patients/:id/restore', async (req, res) => {
  const p = await store.setDeleted(req.params.id, false, { now: now(), by: req.user.email });
  if (!p) return res.status(404).json({ error: 'not_found', message: 'Record not found.' });
  audit(req, 'restore', { patientId: p.id, patientName: p.name || '', category: p.category });
  await emitEvent(req, 'restored', p);
  res.json({ patient: publicPatient(p) });
});

api.post('/patients/bulk-delete', requireAdmin, async (req, res) => {
  const ids = Array.isArray(req.body?.ids) ? req.body.ids.slice(0, 5000) : [];
  let n = 0;
  for (const id of ids) { if (await store.setDeleted(String(id), true, { now: now(), by: req.user.email })) n++; }
  audit(req, 'bulk-delete', { count: n });
  res.json({ deleted: n });
});

// Import a backup downloaded from the original browser-only tracker
api.post('/import', requireAdmin, async (req, res) => {
  const list = Array.isArray(req.body?.patients) ? req.body.patients : null;
  if (!list) return res.status(400).json({ error: 'invalid', message: 'That file has no patient records.' });
  const skipDemo = req.body?.skipDemo !== false;
  const t = now();
  const records = [], problems = [];
  list.forEach((raw, i) => {
    if (!raw || typeof raw !== 'object' || (skipDemo && isDemo(raw))) return;
    const copy = { ...raw };
    if (!TAB_KEYS.includes(copy.category)) copy.category = 'Procter Pay Attention';
    VEIN_UNITS_FIX(copy);
    let { value, error } = sanitizePatient(copy);
    if (error) {
      // Keep the record rather than drop it: park nameless records on a tab where names are optional
      ({ value, error } = sanitizePatient({ ...copy, category: 'Procter Pay Attention', notes: `[Imported from ${copy.category}] ${copy.notes || ''}`.trim() }));
      if (error) { problems.push(`Row ${i + 1}: ${error}`); return; }
    }
    const srcId = String(raw.id || `row${i}`).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 80);
    records.push({
      id: 'imp_' + srcId,
      ...value,
      deleted: false, demo: false,
      createdAt: Number(raw.createdAt) || t,
      updatedAt: t,
      updatedBy: req.user.email,
      sourceUpdatedAt: Number(raw.updatedAt) || 0,
      paApprovedAt: value.paStatus === 'Approved' ? (Number(raw.paApprovedAt) || Number(raw.updatedAt) || t) : '',
      paApprovedBy: value.paStatus === 'Approved' ? String(raw.paApprovedBy || raw.updatedBy || '').slice(0, 200) : '',
      importedFrom: String(raw.updatedBy || 'browser backup').slice(0, 200)
    });
  });
  const r = await store.importPatients(records);
  audit(req, 'import', { count: r.added, skipped: r.skipped });
  res.json({ ...r, problems });
});
function VEIN_UNITS_FIX(rec) {
  // Old prototype stored units like "2 cc"; keep the number
  for (const k of Object.keys(rec)) {
    if (k.endsWith('_units') && typeof rec[k] === 'string') {
      const n = parseFloat(rec[k]); rec[k] = Number.isFinite(n) ? n : '';
    }
  }
}

/* Surgeons and settings */
api.put('/surgeons', async (req, res) => {
  const list = Array.isArray(req.body?.surgeons) ? req.body.surgeons : null;
  if (!list) return res.status(400).json({ error: 'invalid', message: 'Send a list of surgeon names.' });
  const clean = [...new Set(list.map(s => String(s).trim().slice(0, 120)).filter(Boolean))].slice(0, 100);
  await store.setConfig('surgeons', { list: clean, updatedAt: now() });
  audit(req, 'surgeons', { count: clean.length });
  res.json({ surgeons: clean });
});

api.put('/settings', requireAdmin, async (req, res) => {
  const b = req.body?.settings || {};
  const settings = {
    practiceName: String(b.practiceName || DEFAULT_SETTINGS.practiceName).trim().slice(0, 120),
    defaultLocation: ['ATL', 'STB', 'Newnan'].includes(b.defaultLocation) ? b.defaultLocation : 'ATL',
    exportPrefix: String(b.exportPrefix || DEFAULT_SETTINGS.exportPrefix).replace(/[^\w\- ]+/g, '').trim().slice(0, 80) || DEFAULT_SETTINGS.exportPrefix
  };
  await store.setConfig('settings', { ...settings, updatedAt: now() });
  audit(req, 'settings');
  res.json({ settings });
});

/* Notifications: read markers are per user and follow them to any computer */
api.post('/notifications/read', async (req, res) => {
  const items = Array.isArray(req.body?.items) ? req.body.items.slice(0, 500) : [];
  const st = await notifState(req.user.email);
  const cutoff = now() - EVENT_WINDOW_MS - 864e5;
  for (const it of items) {
    const id = String(it?.id || '').slice(0, 100), at = Number(it?.at) || now();
    if (id && at > st.readAllAt) st.read[id] = at;
  }
  for (const [id, at] of Object.entries(st.read)) if (at < cutoff || at <= st.readAllAt) delete st.read[id];
  await store.setNotifState(req.user.email, st);
  res.json({ notif: st });
});

api.post('/notifications/read-all', async (req, res) => {
  const st = { readAllAt: now(), read: {} };
  await store.setNotifState(req.user.email, st);
  res.json({ notif: st });
});

/* Users (admin) */
api.get('/users', requireAdmin, async (req, res) => {
  const users = await store.listUsers();
  res.json({ users: users.sort((a, b) => a.email.localeCompare(b.email)) });
});

api.post('/users', requireAdmin, async (req, res) => {
  const email = sanitizeEmail(req.body?.email);
  if (!email) return res.status(400).json({ error: 'invalid', message: 'Enter a full email address, like name@beltlinehealth.com.' });
  if (await store.getUser(email)) return res.status(409).json({ error: 'exists', message: `${email} is already authorized.` });
  const role = req.body?.role === 'admin' ? 'admin' : 'staff';
  await store.putUser({ email, role, addedBy: req.user.email, addedAt: now() });
  audit(req, 'user-add', { target: email, role });
  res.status(201).json({ ok: true });
});

api.patch('/users/:email', requireAdmin, async (req, res) => {
  const u = await store.getUser(req.params.email);
  if (!u) return res.status(404).json({ error: 'not_found', message: 'User not found.' });
  const role = req.body?.role === 'admin' ? 'admin' : 'staff';
  if (u.role === 'admin' && role === 'staff') {
    if (ADMIN_EMAILS.some(a => lc(a) === lc(u.email))) return res.status(400).json({ error: 'locked', message: `${u.email} is set as an administrator in the server configuration (ADMIN_EMAILS).` });
    const admins = (await store.listUsers()).filter(x => x.role === 'admin');
    if (admins.length <= 1) return res.status(400).json({ error: 'last_admin', message: 'Keep at least one administrator.' });
  }
  await store.putUser({ ...u, role });
  audit(req, 'user-role', { target: u.email, role });
  res.json({ ok: true });
});

api.delete('/users/:email', requireAdmin, async (req, res) => {
  const u = await store.getUser(req.params.email);
  if (!u) return res.status(404).json({ error: 'not_found', message: 'User not found.' });
  if (lc(u.email) === lc(req.user.email)) return res.status(400).json({ error: 'self', message: 'You can’t remove your own access.' });
  if (ADMIN_EMAILS.some(a => lc(a) === lc(u.email))) return res.status(400).json({ error: 'locked', message: `${u.email} is set as an administrator in the server configuration (ADMIN_EMAILS).` });
  await store.deleteUser(u.email);
  audit(req, 'user-remove', { target: u.email });
  res.json({ ok: true, user: u });
});

api.post('/users/restore', requireAdmin, async (req, res) => {
  // Re-adds a user that was just removed (Undo)
  const email = sanitizeEmail(req.body?.email);
  if (!email) return res.status(400).json({ error: 'invalid', message: 'Invalid email.' });
  await store.putUser({ email, role: req.body?.role === 'admin' ? 'admin' : 'staff', addedBy: req.user.email, addedAt: now() });
  audit(req, 'user-add', { target: email });
  res.json({ ok: true });
});

api.post('/users/reset', requireAdmin, async (req, res) => {
  let added = 0;
  for (const email of DEFAULT_USERS) {
    if (!(await store.getUser(email))) { await store.putUser({ email, role: 'staff', addedBy: req.user.email, addedAt: now() }); added++; }
  }
  audit(req, 'users-reset', { count: added });
  res.json({ added });
});

/* Activity log and backup (admin) */
api.get('/audit', requireAdmin, async (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 200, 1000);
  res.json({ entries: await store.listAudit(limit) });
});

api.get('/backup', requireAdmin, async (req, res) => {
  const [patients, c, users] = await Promise.all([store.listPatients(), cfg(), store.listUsers()]);
  audit(req, 'backup', { count: patients.length });
  res.json({ app: 'vein-clinic-tracker', version: 3, exportedAt: new Date().toISOString(), patients: patients.map(publicPatient), surgeons: c.surgeons, users: users.map(u => u.email), settings: c.settings });
});

api.use((req, res) => res.status(404).json({ error: 'not_found', message: 'Unknown API route.' }));
app.use('/api', api);

/* Static front end */
const dist = path.join(__dirname, '..', 'dist');
app.use(express.static(dist, {
  index: false,
  setHeaders(res, file) {
    res.set('Cache-Control', /\.(woff2|js|css)$/.test(file) && /\.[0-9a-f]{8}\./.test(file) ? 'public, max-age=31536000, immutable' : 'no-cache');
  }
}));
app.get('/{*splat}', (req, res) => {
  res.set('Cache-Control', 'no-cache');
  res.sendFile(path.join(dist, 'index.html'));
});

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({ error: 'server_error', message: 'Something went wrong on the server. Try again; if it keeps happening, contact your administrator.' });
});

app.listen(PORT, () => console.log(`Vein Clinic Tracker listening on :${PORT} (store: ${store.kind}${DEV_AUTH ? ', DEV AUTH' : ''})`));
