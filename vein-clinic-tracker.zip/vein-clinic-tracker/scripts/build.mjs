// Builds the front end into dist/: bundled JS, compiled Tailwind CSS, self-hosted fonts.
import { build } from 'esbuild';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dist = path.join(root, 'dist');
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(path.join(dist, 'fonts'), { recursive: true });
const hash = buf => crypto.createHash('sha256').update(buf).digest('hex').slice(0, 8);

// JS
const js = await build({
  entryPoints: [path.join(root, 'client/app.js')],
  bundle: true, minify: true, format: 'iife', target: ['es2020'], write: false, legalComments: 'none'
});
const jsBuf = Buffer.from(js.outputFiles[0].contents);
const jsName = `app.${hash(jsBuf)}.js`;
fs.writeFileSync(path.join(dist, jsName), jsBuf);

// Fonts
for (const w of [400, 500, 600, 700]) {
  fs.copyFileSync(
    path.join(root, `node_modules/@fontsource/public-sans/files/public-sans-latin-${w}-normal.woff2`),
    path.join(dist, 'fonts', `public-sans-${w}.woff2`)
  );
}

// CSS
const tmpCss = path.join(dist, '_app.css');
execFileSync(process.execPath, [
  path.join(root, 'node_modules/tailwindcss/lib/cli.js'),
  '-c', path.join(root, 'tailwind.config.cjs'),
  '-i', path.join(root, 'client/styles.css'),
  '-o', tmpCss, '--minify'
], { stdio: 'inherit' });
const cssBuf = fs.readFileSync(tmpCss);
fs.rmSync(tmpCss);
const cssName = `app.${hash(cssBuf)}.css`;
fs.writeFileSync(path.join(dist, cssName), cssBuf);

// HTML
const html = fs.readFileSync(path.join(root, 'client/index.html'), 'utf8')
  .replace('%CSS%', `/${cssName}`)
  .replace('%JS%', `/${jsName}`);
fs.writeFileSync(path.join(dist, 'index.html'), html);
fs.copyFileSync(path.join(root, 'client/favicon.svg'), path.join(dist, 'favicon.svg'));
console.log(`Built dist/: ${jsName} (${(jsBuf.length / 1024).toFixed(0)} KB), ${cssName} (${(cssBuf.length / 1024).toFixed(0)} KB)`);
