import { test } from 'node:test';
import assert from 'node:assert/strict';
import { sanitizePatient } from '../server/schema.js';

test('BBA ID is optional on Promo and Procter Pay Attention', () => {
  assert.ok(sanitizePatient({ category: 'Promo' }).value);
  assert.ok(sanitizePatient({ category: 'Procter Pay Attention' }).value);
});

test('BBA ID is required on the other five tabs', () => {
  for (const c of ['Dr. Procter', 'Dr. Danthuluri', 'PO Vein FU', 'PA DENIED', 'Not Interested Now or excluded']) {
    assert.match(sanitizePatient({ category: c }).error, /required/);
    assert.ok(sanitizePatient({ category: c, bbaId: 'BBA-1' }).value);
    assert.ok(sanitizePatient({ category: c, bbaId: 'BBA-1' }).value.name === undefined);
  }
});

test('unknown fields are dropped and types are enforced', () => {
  const { value } = sanitizePatient({ category: 'PO Vein FU', bbaId: 'B', l_aasv_proc: 'RFA', initialUsDate: '2026-10-01', usRemapDate: '2026-11-02', evil: '<script>', r_gsv_units: '2 cc', po30DayDone: 'true', po30Day: '2026-01-02' });
  assert.equal(value.evil, undefined);
  assert.equal(value.l_aasv_proc, 'RFA');
  assert.equal(value.initialUsDate, '2026-10-01');
  assert.equal(value.usRemapDate, '2026-11-02');
  assert.equal(value.r_gsv_units, 2);
  assert.equal(value.po30DayDone, true);
  assert.match(sanitizePatient({ category: 'Promo', usDate: 'tomorrow' }).error, /date/);
  assert.match(sanitizePatient({ category: 'Nope' }).error, /Unknown/);
});

test('server-only approval stamps are never accepted from the browser', () => {
  const { value } = sanitizePatient({ category: 'Promo', paApprovedAt: 1, paApprovedBy: 'x' });
  assert.equal(value.paApprovedAt, undefined);
  assert.equal(value.paApprovedBy, undefined);
});

test('treatments are validated', () => {
  const { value } = sanitizePatient({ category: 'Promo', treatments: [{ id: 'a', date: '2026-10-01', postUsDate: '2026-10-03', surgeon: 'Dr. V. Danthuluri', veins: { r_gsv: 'RFA', bogus: 'x' } }] });
  assert.deepEqual(value.treatments, [{ id: 'a', date: '2026-10-01', postUsDate: '2026-10-03', surgeon: 'Dr. V. Danthuluri', veins: { r_gsv: 'RFA' } }]);
  assert.match(sanitizePatient({ category: 'Promo', treatments: [{ date: 'soon' }] }).error, /date/);
});
