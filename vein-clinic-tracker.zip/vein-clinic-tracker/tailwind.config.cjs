module.exports = {
  content: ['./client/**/*.{html,js}'],
  theme: {
    extend: {
      colors: {
        bg: 'var(--bg)', surface: 'var(--surface)', sunken: 'var(--sunken)',
        ink: 'var(--ink)', muted: 'var(--muted)', line: 'var(--line)',
        accent: 'var(--accent)', 'accent-soft': 'var(--accent-soft)',
        side: 'var(--side)', 'side-ink': 'var(--side-ink)',
        danger: 'var(--danger)', 'danger-soft': 'var(--danger-soft)',
        warn: 'var(--warn)', 'warn-soft': 'var(--warn-soft)',
        ok: 'var(--ok)', 'ok-soft': 'var(--ok-soft)'
      },
      fontFamily: { sans: ['"Public Sans"', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'] }
    }
  }
};
